#!/bin/bash

# create a text file named my_repos.txt with organization and repository name in each new line
# in format old_organization,old_repository,new_organizaiton,new_repository
# for example CCIH,companies-api,ccih_new,new_companies_api
# run in git bash below two commands
# chmod +x ./move_repos.sh
# for line in $(cat my_repos.txt); do ./move_repos.sh $line; done

set -e

INPUT="$1"

input_split=(${INPUT//,/ })
OLD_ORG=${input_split[0]}
OLD_REP=${input_split[1]}
NEW_ORG=${input_split[2]}
NEW_REP=${input_split[3]}

echo "     -[ ---------------------------- ]- "
echo "     -[ processing $OLD_ORG/$OLD_REP ]- "

git clone --bare https://github.com/$OLD_ORG/$OLD_REP.git
cd $OLD_REP.git
git push --mirror https://github.com/$NEW_ORG/$NEW_REP.git
echo "     -[ successfully cloned repository $OLD_ORG/$OLD_REP to new location at $NEW_ORG/$NEW_REP ]- "

cd ..
rm -rf $OLD_REP.git
echo "     -[ done with $OLD_ORG/$OLD_REP  ]- "
