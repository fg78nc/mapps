package com.plumstep;

import java.util.HashMap;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import static org.junit.Assert.assertEquals;

@ActiveProfiles("default")
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.DEFINED_PORT, classes = {ClientApplication.class})
public class ClientIntegrationTest {

    @Autowired
    private RestTemplate restTemplate;

    private String serverUrl = "https://sandbox.api.visa.com/vmss/service/v1/searchTerminatedRequest";
    private String payload = "{\n"
            + "    \"encData\": \"eyJlbmMiOiJBMTI4R0NNIiwiaWF0IjoxNTk3NDMwNTExMjg4LCJhbGciOiJSU0EtT0FFUC0yNTYiLCJraWQiOiIyNWE2NDMxOC0wY2NjLTRlNTYtOWI3MS05NDlhNmZiNmJhMTEifQ.wYDqmqHlNDRbcejwMWUXzXzNvsd2P0XIlmkJ80JlB4iZSH-1s3sOPS9wmLd96tghvb1iLa4bazojNEArxmh0bZYzrj2P5zuEXQjHLXsfYaLfeaiXpcsn_tK31d3HNoVQz7lK7coy1oT8c49JK7gY0Yb7EOgM1Fp4EyIlmeBOmpNxmyznyNaOHwOix_qfg7LrPwWe0e5Qr-GK7z2ZieqB61gV3nB9dH59trQpCWQLmiezcYSehxIq68xs7QY_o5Zm-Gqwa3xLIfZr0GBg7KVvmBSqPQPdKiYi56XltGCVcNSR1I0YjgkJPiP6QOJVy3rXO9SEmk3Nus9ZguhZ3t-aNQ.dtY0_hqd-cICO5Uk.4G_gEpMNxImpIgqWcoOY6AlkBg4XBK59cD8heRF-GfQ7xjfZ0cPDY3USNQ0xDhT79b3SFOscQUEJaQFriMNB4oFoygOVHroP8kPVDykA5CTpGQL-E8T0u29ZpnEYtUCeTEx2xa5O1QtXIfmi61JoS7kuXZpdVZIgzpHaArDHYpHbb-VMEuuTfs_PYWG-0Wj5w7L__26EBQdSCgLIY3NeC5JAjCEYvKf-uJ20ESyDbvI25P5DrU97oqSCujqeFjI5RqQl4ZxBnHEjk43gDtTTUpfP5bNmSKSK89rb9yiyQ3egBaC5M-Wr2CyxwoFraPCqnY5ePRKPWvG6BpzUHW-0dbEuFXqELmflaQG8CiYN1trPfHG60Ri2f5KccEtSjXtLdziNf8n0O_eEGw8aOlqj3nR2gpwWUEq4nUXDPYEj_ZICyYfSeT8VoWCgHD7Cpe0zhoXV8OsBkGHQklSDPbFCvAcq-EsEyWpmIechYhpDxCN0ykG1jU2wLa5VN-vZCaLC2KPvgLAKXRJBjy7Ux36ccnJLYBgE5ZLtYcV_OXYqtCFjxFv9LJ-a7C-1fo8dodbrAp63ILzTHh0Dujz8WQej5YRVStGmubYsR5TvoI_jySfgjjuSAX0E1H8SDHS00OmnqRqNJxegMsjRmepet9ceiZv3n-5-NNBy4ov9owHb4xPLLlKV7UDtG_o3l2u0ZzOaCqXhXCygT2HHV10jlrJkh2eCHAU25Kp9qbIdvW-R55jwuOnXggUpDzyXbnS8FVQ2tl5a-kpsNM83w4mOcJQ4UOn2QdMZqO1mhe-KTqzmLoB6hFAnUCKcZKZq3TmyC_kZzVsggXLnRASCe9G8S5Sfb1O4WPKW3oKAHh1PDCs2IMIF6bJasptf1zf1k6oHZC64m4D3BKn8zRvKDXG4sEWcebDmaw9IPCt4kh59tUK-pqPThh0BaYfEWlLUrE1LsGjUBpSUwSBtQImW1ZLGNKtBmLdYckaiEhS-lR8EgCgR9k_ABisCH4qHxpdNfyCIL1KLsihR7UYowmm83mVZuPoqoPmUCovG6PlZm8j_CCd7H5elVnLkHE4WZcYq2C-PBaFDc6aHgi-F99yBKyDQRENQKxI1xY1ddljbg85tZg5sgnYt14iz0i_M7vfvX3pZmolDfTReylJjkNUG9hH96JK2NAff5FsFRorkxqzUwHfQhRzwQ-udbtXBRbdQO96-NCMklv_esYiE6bEgnvJcYF51TEt452argfD2bcZDl2esD-dnC5EBtvLzUjQETPzx6ewVZ6_ZZbugxVN7XkSuyRpPMHlA98LAGYk1w9_gVtz5qoiV2g1aXFBVLkf-aOj2Az_Yh9mK9N0hzF8Xgx4wDszrUH7e2InY6LRIE5z5LNKNxrFyy1VwCnWzTn8fTrJq3Ke04bBrm2ijTSYox1-IdPrZDq9_0-2IrPnpo1G54u2ktoz4J29hJDacci1pmQDIcb9WRkPovKT7ta3Iv0w2dSkc8vnD2J1vGmm9-OlM8cjk9JfBHTnwyvPDbufLwfuXVte5ejgw1cKclPGVP-QNnZQ1nzo_a4tdF6qFNHhDhc3qW3vcOt1CHfSh5wqHvKkZ2wTGR2Boc0-iMmtkFgQSeqPHrYWtcgyIV1eD1n-OsjfedZF1JYOLnqkzt-EEuisWvI--y1lc1akcqjDTGOocdYG2ahuPBdO3HXmUbo9cjma2Pioo5dalWId_uh29_gnKjqXQd4BCWFTRj6pvD52GlXBGoLAQNbGEYG8XcEa04Moevw_z30WyuGj7civ65M0jNW6PXkTc9Vv4dWVZwsw7ALjlY2F8j23KErdwnWCtQV5DxR01sylDoCddHNWvzhP8_jZmMDpJXdwi94LtdYTxxOGbU4QVc9YEF1kbOWjkGOfZzVV746WsaksOIxdxhXipXF4Zh_vp48pBeyaUbU_F4xs2ZW3lrcYZ63YYAvxlRM9h1ucnr8ZhXAVKx1uIrShQOJxnUpIWE1jDFnRkODo9OBlkrNYhvtIjw7XojeUmDNsc1D48l8Z7-R_4opXU1eT3N6zWZFle2xLQfxI4xt1eDUta_P9KtkudMOFmV9qVoByltobqAxfhOaiIBHpIvQJNnQs0PgkuUjCiv6XK9rFAA0Muf0zZiXIE019uSo_trNZPxgQXezuZ1rjjgvMacIYyKhp2J4NW7LITTMPqdJ1NEtfxMQ-85YKacQVH8F23WrJ6SSH8bwDxtaczCIvYQgdgj2p4lIvVRw_M5kXzTuDTTkaRSjSdNfUDbC0IZzruCNJ7m0vYjtDg6r3qwH7PcDreXnAzDYFtDPLK-uVgZBTIIhjDHIrUczH2U8gm556sgcCXLMYrM0CGUMwEWJNzpotZwSFHMxIG0hLt589mAA-NABwNsh5MFkAf1lg8POjP3ftzo-F9_C5t4z0_SA22yjWPaHiCTY-b-QpXdo8EZI0Gl9yo6h_ooLR2wSKBUGGI9d-RHMo_ILp5r8ffP8bnA-Uk9I4TvSlv1vnf_UqENg1qjOh4PU9OkgoeuXO-JBjR43OJ3Oku3BpScUtJsawmm2u9kGov03PE8CyQYRRfrjN9kebenjHE_jNu9Vkl8T4kPR_c6lQLTnOunaRdbbaZnzi5idnLWiim6S0oCwiZYIdwcLg2ax5B8cjSbXI.rlTp_ynSgvFCdfibWjj5SQ\"\n"
            + "}";

    @Test
    public void testGet() {
        MultiValueMap<String,String> headers = new HttpHeaders();
        headers.add(HttpHeaders.ACCEPT, "application/json");
        headers.add("request-message-id", "ccih_request_1");
        headers.add("request-message-ts", "2020-08-12T01:10:35.252Z");
        headers.add("keyId", "25a64318-0ccc-4e56-9b71-949a6fb6ba11");
        headers.add(HttpHeaders.CONTENT_TYPE, "application/json");
        headers.add(HttpHeaders.AUTHORIZATION, "Basic UldGS0pIUTlSTU0wUDAySFFZUkQyMWhBUFgxY21hWUZjTW1BRmcxanpKUGtwRmhNdzo5QlI3dGU0aVU1MkJwQzlTT3FNOUJTWUI1QXpOcFY5Ng==");

        HttpEntity<String> request =
                new HttpEntity<String>(payload, headers);

        ResponseEntity<String> getResponse =
                restTemplate.postForEntity(serverUrl, request, String.class);
        System.out.println(getResponse.getBody());
        assertEquals(HttpStatus.OK, getResponse.getStatusCode());
    }
}
