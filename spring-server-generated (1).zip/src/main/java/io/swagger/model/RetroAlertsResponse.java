package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.RetroSearchRequestAndAlerts;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * RetroAlertsResponse
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2020-07-02T11:41:02.721Z")

public class RetroAlertsResponse   {
  @JsonProperty("pageOffset")
  private Integer pageOffset = null;

  @JsonProperty("pageSize")
  private Integer pageSize = null;

  @JsonProperty("numSearchRequestRecordsTotal")
  private Integer numSearchRequestRecordsTotal = null;

  @JsonProperty("numSearchRequestRecordsReturned")
  private Integer numSearchRequestRecordsReturned = null;

  @JsonProperty("retroSearchRequestAndAlerts")
  private RetroSearchRequestAndAlerts retroSearchRequestAndAlerts = null;

  public RetroAlertsResponse pageOffset(Integer pageOffset) {
    this.pageOffset = pageOffset;
    return this;
  }

  /**
   * Pagination can be supported using pageOffet and pageSize. An offset is simply the number of matched records you wish to skip before selecting records. The zero-based offset to start at. An offset of 10 starts at the 11th record. 
   * @return pageOffset
  **/
  @ApiModelProperty(value = "Pagination can be supported using pageOffet and pageSize. An offset is simply the number of matched records you wish to skip before selecting records. The zero-based offset to start at. An offset of 10 starts at the 11th record. ")


  public Integer getPageOffset() {
    return pageOffset;
  }

  public void setPageOffset(Integer pageOffset) {
    this.pageOffset = pageOffset;
  }

  public RetroAlertsResponse pageSize(Integer pageSize) {
    this.pageSize = pageSize;
    return this;
  }

  /**
   * The maximum number of matched records to retrieve within the current page of retroactive alerts.
   * @return pageSize
  **/
  @ApiModelProperty(value = "The maximum number of matched records to retrieve within the current page of retroactive alerts.")


  public Integer getPageSize() {
    return pageSize;
  }

  public void setPageSize(Integer pageSize) {
    this.pageSize = pageSize;
  }

  public RetroAlertsResponse numSearchRequestRecordsTotal(Integer numSearchRequestRecordsTotal) {
    this.numSearchRequestRecordsTotal = numSearchRequestRecordsTotal;
    return this;
  }

  /**
   * Total number of search request records with retroactive alerts generated in the requested alert date range.
   * @return numSearchRequestRecordsTotal
  **/
  @ApiModelProperty(value = "Total number of search request records with retroactive alerts generated in the requested alert date range.")


  public Integer getNumSearchRequestRecordsTotal() {
    return numSearchRequestRecordsTotal;
  }

  public void setNumSearchRequestRecordsTotal(Integer numSearchRequestRecordsTotal) {
    this.numSearchRequestRecordsTotal = numSearchRequestRecordsTotal;
  }

  public RetroAlertsResponse numSearchRequestRecordsReturned(Integer numSearchRequestRecordsReturned) {
    this.numSearchRequestRecordsReturned = numSearchRequestRecordsReturned;
    return this;
  }

  /**
   * Number of search request records with retroactive alerts returned in the response.
   * @return numSearchRequestRecordsReturned
  **/
  @ApiModelProperty(value = "Number of search request records with retroactive alerts returned in the response.")


  public Integer getNumSearchRequestRecordsReturned() {
    return numSearchRequestRecordsReturned;
  }

  public void setNumSearchRequestRecordsReturned(Integer numSearchRequestRecordsReturned) {
    this.numSearchRequestRecordsReturned = numSearchRequestRecordsReturned;
  }

  public RetroAlertsResponse retroSearchRequestAndAlerts(RetroSearchRequestAndAlerts retroSearchRequestAndAlerts) {
    this.retroSearchRequestAndAlerts = retroSearchRequestAndAlerts;
    return this;
  }

  /**
   * Get retroSearchRequestAndAlerts
   * @return retroSearchRequestAndAlerts
  **/
  @ApiModelProperty(value = "")

  @Valid

  public RetroSearchRequestAndAlerts getRetroSearchRequestAndAlerts() {
    return retroSearchRequestAndAlerts;
  }

  public void setRetroSearchRequestAndAlerts(RetroSearchRequestAndAlerts retroSearchRequestAndAlerts) {
    this.retroSearchRequestAndAlerts = retroSearchRequestAndAlerts;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    RetroAlertsResponse retroAlertsResponse = (RetroAlertsResponse) o;
    return Objects.equals(this.pageOffset, retroAlertsResponse.pageOffset) &&
        Objects.equals(this.pageSize, retroAlertsResponse.pageSize) &&
        Objects.equals(this.numSearchRequestRecordsTotal, retroAlertsResponse.numSearchRequestRecordsTotal) &&
        Objects.equals(this.numSearchRequestRecordsReturned, retroAlertsResponse.numSearchRequestRecordsReturned) &&
        Objects.equals(this.retroSearchRequestAndAlerts, retroAlertsResponse.retroSearchRequestAndAlerts);
  }

  @Override
  public int hashCode() {
    return Objects.hash(pageOffset, pageSize, numSearchRequestRecordsTotal, numSearchRequestRecordsReturned, retroSearchRequestAndAlerts);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class RetroAlertsResponse {\n");
    
    sb.append("    pageOffset: ").append(toIndentedString(pageOffset)).append("\n");
    sb.append("    pageSize: ").append(toIndentedString(pageSize)).append("\n");
    sb.append("    numSearchRequestRecordsTotal: ").append(toIndentedString(numSearchRequestRecordsTotal)).append("\n");
    sb.append("    numSearchRequestRecordsReturned: ").append(toIndentedString(numSearchRequestRecordsReturned)).append("\n");
    sb.append("    retroSearchRequestAndAlerts: ").append(toIndentedString(retroSearchRequestAndAlerts)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

