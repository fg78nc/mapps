package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * Principal
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2020-07-02T11:41:02.721Z")

public class Principal   {
  @JsonProperty("name")
  private String name = null;

  @JsonProperty("businessPhoneNumber")
  private String businessPhoneNumber = null;

  @JsonProperty("businessEmailAddress")
  private String businessEmailAddress = null;

  @JsonProperty("principalID")
  private String principalID = null;

  @JsonProperty("SSN")
  private String SSN = null;

  @JsonProperty("driverLicenseNumber")
  private String driverLicenseNumber = null;

  @JsonProperty("residentIDOrNationalID")
  private String residentIDOrNationalID = null;

  @JsonProperty("passportNumber")
  private String passportNumber = null;

  public Principal name(String name) {
    this.name = name;
    return this;
  }

  /**
   * The name of the individual that is registered as the merchant or agent principal/owner.
   * @return name
  **/
  @ApiModelProperty(example = "Bill Smith", required = true, value = "The name of the individual that is registered as the merchant or agent principal/owner.")
  @NotNull

@Pattern(regexp="^(\\w|\\s|-|,|�|\\(|\\)|\\`|\\'|\\.|/|\\\\)+$") 
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public Principal businessPhoneNumber(String businessPhoneNumber) {
    this.businessPhoneNumber = businessPhoneNumber;
    return this;
  }

  /**
   * The merchant or agent principal's/owner’s corporate/business contact number. 
   * @return businessPhoneNumber
  **/
  @ApiModelProperty(example = "+861071111222", value = "The merchant or agent principal's/owner’s corporate/business contact number. ")

@Pattern(regexp="^((\\+\\d{1,3}(\\(\\d{1,3}\\)|(\\d{1,3}))\\d{1,5})|((\\(\\d{2,6}\\))|(\\d{2,6})))(\\d{3,4})(\\d{3,4})$") 
  public String getBusinessPhoneNumber() {
    return businessPhoneNumber;
  }

  public void setBusinessPhoneNumber(String businessPhoneNumber) {
    this.businessPhoneNumber = businessPhoneNumber;
  }

  public Principal businessEmailAddress(String businessEmailAddress) {
    this.businessEmailAddress = businessEmailAddress;
    return this;
  }

  /**
   * The merchant or agent principal's/owner’s corporate/business email address. 
   * @return businessEmailAddress
  **/
  @ApiModelProperty(example = "billsmith@snapphoto.com", value = "The merchant or agent principal's/owner’s corporate/business email address. ")

@Pattern(regexp="[A-Za-z0-9._%-]+@[A-Za-z0-9.-]+\\.[a-zA-Z]{2,4}$") 
  public String getBusinessEmailAddress() {
    return businessEmailAddress;
  }

  public void setBusinessEmailAddress(String businessEmailAddress) {
    this.businessEmailAddress = businessEmailAddress;
  }

  public Principal principalID(String principalID) {
    this.principalID = principalID;
    return this;
  }

  /**
   * The merchant or agent principal's/owner’s id from VMSS 1.0.
   * @return principalID
  **/
  @ApiModelProperty(example = "07043453", value = "The merchant or agent principal's/owner’s id from VMSS 1.0.")

@Pattern(regexp="^(\\w|\\s|-|,|�|\\(|\\)|\\`|\\'|\\.|/|;|:|&|\\$|#|!|\\+|\\?|@|=|\\\\)+$") 
  public String getPrincipalID() {
    return principalID;
  }

  public void setPrincipalID(String principalID) {
    this.principalID = principalID;
  }

  public Principal SSN(String SSN) {
    this.SSN = SSN;
    return this;
  }

  /**
   * The merchant or agent principal's/owner’s social security number.
   * @return SSN
  **/
  @ApiModelProperty(example = "000-00-0000", value = "The merchant or agent principal's/owner’s social security number.")

@Pattern(regexp="^\\d{3}-?\\d{2}-?\\d{4}$|^XXX-XX-XXXX$") 
  public String getSSN() {
    return SSN;
  }

  public void setSSN(String SSN) {
    this.SSN = SSN;
  }

  public Principal driverLicenseNumber(String driverLicenseNumber) {
    this.driverLicenseNumber = driverLicenseNumber;
    return this;
  }

  /**
   * The merchant or agent principal's/owner’s driver license number.
   * @return driverLicenseNumber
  **/
  @ApiModelProperty(example = "07043453", value = "The merchant or agent principal's/owner’s driver license number.")

@Pattern(regexp="[\\p{L}\\p{Nd}\\p{Nl}\\p{Z}]*") 
  public String getDriverLicenseNumber() {
    return driverLicenseNumber;
  }

  public void setDriverLicenseNumber(String driverLicenseNumber) {
    this.driverLicenseNumber = driverLicenseNumber;
  }

  public Principal residentIDOrNationalID(String residentIDOrNationalID) {
    this.residentIDOrNationalID = residentIDOrNationalID;
    return this;
  }

  /**
   * The merchant or agent principal's/owner’s resident ID number or National ID number.
   * @return residentIDOrNationalID
  **/
  @ApiModelProperty(example = "07043453", value = "The merchant or agent principal's/owner’s resident ID number or National ID number.")

@Pattern(regexp="[\\p{L}\\p{Nd}\\p{Nl}\\p{Z}]*") 
  public String getResidentIDOrNationalID() {
    return residentIDOrNationalID;
  }

  public void setResidentIDOrNationalID(String residentIDOrNationalID) {
    this.residentIDOrNationalID = residentIDOrNationalID;
  }

  public Principal passportNumber(String passportNumber) {
    this.passportNumber = passportNumber;
    return this;
  }

  /**
   * The merchant or agent principal's/owner's passport number. 
   * @return passportNumber
  **/
  @ApiModelProperty(example = "07043453", value = "The merchant or agent principal's/owner's passport number. ")

@Pattern(regexp="[\\p{L}\\p{Nd}\\p{Nl}\\p{Z}]*") 
  public String getPassportNumber() {
    return passportNumber;
  }

  public void setPassportNumber(String passportNumber) {
    this.passportNumber = passportNumber;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Principal principal = (Principal) o;
    return Objects.equals(this.name, principal.name) &&
        Objects.equals(this.businessPhoneNumber, principal.businessPhoneNumber) &&
        Objects.equals(this.businessEmailAddress, principal.businessEmailAddress) &&
        Objects.equals(this.principalID, principal.principalID) &&
        Objects.equals(this.SSN, principal.SSN) &&
        Objects.equals(this.driverLicenseNumber, principal.driverLicenseNumber) &&
        Objects.equals(this.residentIDOrNationalID, principal.residentIDOrNationalID) &&
        Objects.equals(this.passportNumber, principal.passportNumber);
  }

  @Override
  public int hashCode() {
    return Objects.hash(name, businessPhoneNumber, businessEmailAddress, principalID, SSN, driverLicenseNumber, residentIDOrNationalID, passportNumber);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Principal {\n");
    
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    businessPhoneNumber: ").append(toIndentedString(businessPhoneNumber)).append("\n");
    sb.append("    businessEmailAddress: ").append(toIndentedString(businessEmailAddress)).append("\n");
    sb.append("    principalID: ").append(toIndentedString(principalID)).append("\n");
    sb.append("    SSN: ").append(toIndentedString(SSN)).append("\n");
    sb.append("    driverLicenseNumber: ").append(toIndentedString(driverLicenseNumber)).append("\n");
    sb.append("    residentIDOrNationalID: ").append(toIndentedString(residentIDOrNationalID)).append("\n");
    sb.append("    passportNumber: ").append(toIndentedString(passportNumber)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

