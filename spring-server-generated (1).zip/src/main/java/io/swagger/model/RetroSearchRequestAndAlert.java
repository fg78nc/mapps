package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.PossibleMatches;
import io.swagger.model.RetroSearchRequest;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * RetroSearchRequestAndAlert
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2020-07-02T11:41:02.721Z")

public class RetroSearchRequestAndAlert   {
  @JsonProperty("searchDate")
  private String searchDate = null;

  @JsonProperty("alertDate")
  private String alertDate = null;

  @JsonProperty("retroSearchRequest")
  private RetroSearchRequest retroSearchRequest = null;

  @JsonProperty("possibleMatches")
  private PossibleMatches possibleMatches = null;

  public RetroSearchRequestAndAlert searchDate(String searchDate) {
    this.searchDate = searchDate;
    return this;
  }

  /**
   * The original Search request date.
   * @return searchDate
  **/
  @ApiModelProperty(example = "2018-12-01", value = "The original Search request date.")

@Pattern(regexp="\\d{4}\\-(0[1-9]|1[012])\\-(0[1-9]|[12][0-9]|3[01])$") 
  public String getSearchDate() {
    return searchDate;
  }

  public void setSearchDate(String searchDate) {
    this.searchDate = searchDate;
  }

  public RetroSearchRequestAndAlert alertDate(String alertDate) {
    this.alertDate = alertDate;
    return this;
  }

  /**
   * The date on which the retroactive alert was generated.
   * @return alertDate
  **/
  @ApiModelProperty(example = "2019-02-01", value = "The date on which the retroactive alert was generated.")

@Pattern(regexp="\\d{4}\\-(0[1-9]|1[012])\\-(0[1-9]|[12][0-9]|3[01])$") 
  public String getAlertDate() {
    return alertDate;
  }

  public void setAlertDate(String alertDate) {
    this.alertDate = alertDate;
  }

  public RetroSearchRequestAndAlert retroSearchRequest(RetroSearchRequest retroSearchRequest) {
    this.retroSearchRequest = retroSearchRequest;
    return this;
  }

  /**
   * Get retroSearchRequest
   * @return retroSearchRequest
  **/
  @ApiModelProperty(value = "")

  @Valid

  public RetroSearchRequest getRetroSearchRequest() {
    return retroSearchRequest;
  }

  public void setRetroSearchRequest(RetroSearchRequest retroSearchRequest) {
    this.retroSearchRequest = retroSearchRequest;
  }

  public RetroSearchRequestAndAlert possibleMatches(PossibleMatches possibleMatches) {
    this.possibleMatches = possibleMatches;
    return this;
  }

  /**
   * Get possibleMatches
   * @return possibleMatches
  **/
  @ApiModelProperty(value = "")

  @Valid

  public PossibleMatches getPossibleMatches() {
    return possibleMatches;
  }

  public void setPossibleMatches(PossibleMatches possibleMatches) {
    this.possibleMatches = possibleMatches;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    RetroSearchRequestAndAlert retroSearchRequestAndAlert = (RetroSearchRequestAndAlert) o;
    return Objects.equals(this.searchDate, retroSearchRequestAndAlert.searchDate) &&
        Objects.equals(this.alertDate, retroSearchRequestAndAlert.alertDate) &&
        Objects.equals(this.retroSearchRequest, retroSearchRequestAndAlert.retroSearchRequest) &&
        Objects.equals(this.possibleMatches, retroSearchRequestAndAlert.possibleMatches);
  }

  @Override
  public int hashCode() {
    return Objects.hash(searchDate, alertDate, retroSearchRequest, possibleMatches);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class RetroSearchRequestAndAlert {\n");
    
    sb.append("    searchDate: ").append(toIndentedString(searchDate)).append("\n");
    sb.append("    alertDate: ").append(toIndentedString(alertDate)).append("\n");
    sb.append("    retroSearchRequest: ").append(toIndentedString(retroSearchRequest)).append("\n");
    sb.append("    possibleMatches: ").append(toIndentedString(possibleMatches)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

