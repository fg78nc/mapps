package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * RetroAlertsRequest
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2020-07-02T11:41:02.721Z")

public class RetroAlertsRequest   {
  @JsonProperty("pageOffset")
  private Integer pageOffset = null;

  @JsonProperty("pageSize")
  private Integer pageSize = null;

  @JsonProperty("acquirerBID")
  private String acquirerBID = null;

  @JsonProperty("acquirerCountryOrRegion")
  private String acquirerCountryOrRegion = null;

  @JsonProperty("alertStartDate")
  private String alertStartDate = null;

  @JsonProperty("alertEndDate")
  private String alertEndDate = null;

  public RetroAlertsRequest pageOffset(Integer pageOffset) {
    this.pageOffset = pageOffset;
    return this;
  }

  /**
   * Pagination can be supported using pageOffet and pageSize. An offset is simply the number of matched records you wish to skip before selecting records. The zero-based offset to start at. An offset of 10 starts at the 11th record. 
   * @return pageOffset
  **/
  @ApiModelProperty(value = "Pagination can be supported using pageOffet and pageSize. An offset is simply the number of matched records you wish to skip before selecting records. The zero-based offset to start at. An offset of 10 starts at the 11th record. ")


  public Integer getPageOffset() {
    return pageOffset;
  }

  public void setPageOffset(Integer pageOffset) {
    this.pageOffset = pageOffset;
  }

  public RetroAlertsRequest pageSize(Integer pageSize) {
    this.pageSize = pageSize;
    return this;
  }

  /**
   * The maximum number of matched records to retrieve within the current page of retroactive alerts.
   * @return pageSize
  **/
  @ApiModelProperty(value = "The maximum number of matched records to retrieve within the current page of retroactive alerts.")


  public Integer getPageSize() {
    return pageSize;
  }

  public void setPageSize(Integer pageSize) {
    this.pageSize = pageSize;
  }

  public RetroAlertsRequest acquirerBID(String acquirerBID) {
    this.acquirerBID = acquirerBID;
    return this;
  }

  /**
   * Visa assigned Business Identifier (BID) of the Acquirer.
   * @return acquirerBID
  **/
  @ApiModelProperty(example = "10048640", value = "Visa assigned Business Identifier (BID) of the Acquirer.")

@Pattern(regexp="\\d{8}") 
  public String getAcquirerBID() {
    return acquirerBID;
  }

  public void setAcquirerBID(String acquirerBID) {
    this.acquirerBID = acquirerBID;
  }

  public RetroAlertsRequest acquirerCountryOrRegion(String acquirerCountryOrRegion) {
    this.acquirerCountryOrRegion = acquirerCountryOrRegion;
    return this;
  }

  /**
   * The country or region of the Acquirer.
   * @return acquirerCountryOrRegion
  **/
  @ApiModelProperty(example = "JP", value = "The country or region of the Acquirer.")

@Pattern(regexp="([A-Z]){2}") 
  public String getAcquirerCountryOrRegion() {
    return acquirerCountryOrRegion;
  }

  public void setAcquirerCountryOrRegion(String acquirerCountryOrRegion) {
    this.acquirerCountryOrRegion = acquirerCountryOrRegion;
  }

  public RetroAlertsRequest alertStartDate(String alertStartDate) {
    this.alertStartDate = alertStartDate;
    return this;
  }

  /**
   * Add a start date in the alert date range filter to retrieve the retroactive alerts generated for the inquiries performed by you or a colleague in your organization.
   * @return alertStartDate
  **/
  @ApiModelProperty(example = "2019-01-01", value = "Add a start date in the alert date range filter to retrieve the retroactive alerts generated for the inquiries performed by you or a colleague in your organization.")

@Pattern(regexp="\\d{4}\\-(0[1-9]|1[012])\\-(0[1-9]|[12][0-9]|3[01])$") 
  public String getAlertStartDate() {
    return alertStartDate;
  }

  public void setAlertStartDate(String alertStartDate) {
    this.alertStartDate = alertStartDate;
  }

  public RetroAlertsRequest alertEndDate(String alertEndDate) {
    this.alertEndDate = alertEndDate;
    return this;
  }

  /**
   * Add an end date in the alert date range filter to retrieve the retroactive alerts generated for the inquiries performed by you or a colleague in your organization.
   * @return alertEndDate
  **/
  @ApiModelProperty(example = "2029-06-30", value = "Add an end date in the alert date range filter to retrieve the retroactive alerts generated for the inquiries performed by you or a colleague in your organization.")

@Pattern(regexp="\\d{4}\\-(0[1-9]|1[012])\\-(0[1-9]|[12][0-9]|3[01])$") 
  public String getAlertEndDate() {
    return alertEndDate;
  }

  public void setAlertEndDate(String alertEndDate) {
    this.alertEndDate = alertEndDate;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    RetroAlertsRequest retroAlertsRequest = (RetroAlertsRequest) o;
    return Objects.equals(this.pageOffset, retroAlertsRequest.pageOffset) &&
        Objects.equals(this.pageSize, retroAlertsRequest.pageSize) &&
        Objects.equals(this.acquirerBID, retroAlertsRequest.acquirerBID) &&
        Objects.equals(this.acquirerCountryOrRegion, retroAlertsRequest.acquirerCountryOrRegion) &&
        Objects.equals(this.alertStartDate, retroAlertsRequest.alertStartDate) &&
        Objects.equals(this.alertEndDate, retroAlertsRequest.alertEndDate);
  }

  @Override
  public int hashCode() {
    return Objects.hash(pageOffset, pageSize, acquirerBID, acquirerCountryOrRegion, alertStartDate, alertEndDate);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class RetroAlertsRequest {\n");
    
    sb.append("    pageOffset: ").append(toIndentedString(pageOffset)).append("\n");
    sb.append("    pageSize: ").append(toIndentedString(pageSize)).append("\n");
    sb.append("    acquirerBID: ").append(toIndentedString(acquirerBID)).append("\n");
    sb.append("    acquirerCountryOrRegion: ").append(toIndentedString(acquirerCountryOrRegion)).append("\n");
    sb.append("    alertStartDate: ").append(toIndentedString(alertStartDate)).append("\n");
    sb.append("    alertEndDate: ").append(toIndentedString(alertEndDate)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

