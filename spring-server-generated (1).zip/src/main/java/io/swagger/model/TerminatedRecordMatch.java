package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.AddressMatch;
import io.swagger.model.FinancialAcctsMatch;
import io.swagger.model.PrincipalsMatch;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * TerminatedRecordMatch
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2020-07-02T11:41:02.721Z")

public class TerminatedRecordMatch   {
  @JsonProperty("DBAName")
  private String dbAName = null;

  @JsonProperty("legalName")
  private String legalName = null;

  @JsonProperty("addressMatch")
  private AddressMatch addressMatch = null;

  @JsonProperty("businessPhoneNumbers")
  private String businessPhoneNumbers = null;

  @JsonProperty("businessEmailAddress")
  private String businessEmailAddress = null;

  @JsonProperty("merchantCategoryCodes")
  private String merchantCategoryCodes = null;

  @JsonProperty("tradeOverInternet")
  private String tradeOverInternet = null;

  @JsonProperty("webAddresses")
  private String webAddresses = null;

  @JsonProperty("taxID")
  private String taxID = null;

  @JsonProperty("businessRegistrationNumber")
  private String businessRegistrationNumber = null;

  @JsonProperty("financialAcctsMatch")
  private FinancialAcctsMatch financialAcctsMatch = null;

  @JsonProperty("principalsMatch")
  private PrincipalsMatch principalsMatch = null;

  public TerminatedRecordMatch dbAName(String dbAName) {
    this.dbAName = dbAName;
    return this;
  }

  /**
   * The indicator of the match type for the data field. N = No Match E = Exact Match P = Partial Match
   * @return dbAName
  **/
  @ApiModelProperty(example = "N", value = "The indicator of the match type for the data field. N = No Match E = Exact Match P = Partial Match")

@Pattern(regexp="([NEP]){1}") 
  public String getDbAName() {
    return dbAName;
  }

  public void setDbAName(String dbAName) {
    this.dbAName = dbAName;
  }

  public TerminatedRecordMatch legalName(String legalName) {
    this.legalName = legalName;
    return this;
  }

  /**
   * The indicator of the match type for the data field. N = No Match E = Exact Match P = Partial Match
   * @return legalName
  **/
  @ApiModelProperty(example = "N", value = "The indicator of the match type for the data field. N = No Match E = Exact Match P = Partial Match")

@Pattern(regexp="([NEP]){1}") 
  public String getLegalName() {
    return legalName;
  }

  public void setLegalName(String legalName) {
    this.legalName = legalName;
  }

  public TerminatedRecordMatch addressMatch(AddressMatch addressMatch) {
    this.addressMatch = addressMatch;
    return this;
  }

  /**
   * Get addressMatch
   * @return addressMatch
  **/
  @ApiModelProperty(value = "")

  @Valid

  public AddressMatch getAddressMatch() {
    return addressMatch;
  }

  public void setAddressMatch(AddressMatch addressMatch) {
    this.addressMatch = addressMatch;
  }

  public TerminatedRecordMatch businessPhoneNumbers(String businessPhoneNumbers) {
    this.businessPhoneNumbers = businessPhoneNumbers;
    return this;
  }

  /**
   * The indicator of the match type for the data field. N = No Match E = Exact Match P = Partial Match
   * @return businessPhoneNumbers
  **/
  @ApiModelProperty(example = "N", value = "The indicator of the match type for the data field. N = No Match E = Exact Match P = Partial Match")

@Pattern(regexp="([NEP]){1}") 
  public String getBusinessPhoneNumbers() {
    return businessPhoneNumbers;
  }

  public void setBusinessPhoneNumbers(String businessPhoneNumbers) {
    this.businessPhoneNumbers = businessPhoneNumbers;
  }

  public TerminatedRecordMatch businessEmailAddress(String businessEmailAddress) {
    this.businessEmailAddress = businessEmailAddress;
    return this;
  }

  /**
   * The indicator of the match type for the data field. N = No Match E = Exact Match P = Partial Match
   * @return businessEmailAddress
  **/
  @ApiModelProperty(example = "N", value = "The indicator of the match type for the data field. N = No Match E = Exact Match P = Partial Match")

@Pattern(regexp="([NEP]){1}") 
  public String getBusinessEmailAddress() {
    return businessEmailAddress;
  }

  public void setBusinessEmailAddress(String businessEmailAddress) {
    this.businessEmailAddress = businessEmailAddress;
  }

  public TerminatedRecordMatch merchantCategoryCodes(String merchantCategoryCodes) {
    this.merchantCategoryCodes = merchantCategoryCodes;
    return this;
  }

  /**
   * The indicator of the match type for the data field. N = No Match E = Exact Match P = Partial Match
   * @return merchantCategoryCodes
  **/
  @ApiModelProperty(example = "N", value = "The indicator of the match type for the data field. N = No Match E = Exact Match P = Partial Match")

@Pattern(regexp="([NEP]){1}") 
  public String getMerchantCategoryCodes() {
    return merchantCategoryCodes;
  }

  public void setMerchantCategoryCodes(String merchantCategoryCodes) {
    this.merchantCategoryCodes = merchantCategoryCodes;
  }

  public TerminatedRecordMatch tradeOverInternet(String tradeOverInternet) {
    this.tradeOverInternet = tradeOverInternet;
    return this;
  }

  /**
   * The indicator of the match type for the data field. N = No Match E = Exact Match P = Partial Match
   * @return tradeOverInternet
  **/
  @ApiModelProperty(example = "N", value = "The indicator of the match type for the data field. N = No Match E = Exact Match P = Partial Match")

@Pattern(regexp="([NEP]){1}") 
  public String getTradeOverInternet() {
    return tradeOverInternet;
  }

  public void setTradeOverInternet(String tradeOverInternet) {
    this.tradeOverInternet = tradeOverInternet;
  }

  public TerminatedRecordMatch webAddresses(String webAddresses) {
    this.webAddresses = webAddresses;
    return this;
  }

  /**
   * The indicator of the match type for the data field. N = No Match E = Exact Match P = Partial Match
   * @return webAddresses
  **/
  @ApiModelProperty(example = "N", value = "The indicator of the match type for the data field. N = No Match E = Exact Match P = Partial Match")

@Pattern(regexp="([NEP]){1}") 
  public String getWebAddresses() {
    return webAddresses;
  }

  public void setWebAddresses(String webAddresses) {
    this.webAddresses = webAddresses;
  }

  public TerminatedRecordMatch taxID(String taxID) {
    this.taxID = taxID;
    return this;
  }

  /**
   * The indicator of the match type for the data field. N = No Match E = Exact Match P = Partial Match
   * @return taxID
  **/
  @ApiModelProperty(example = "N", value = "The indicator of the match type for the data field. N = No Match E = Exact Match P = Partial Match")

@Pattern(regexp="([NEP]){1}") 
  public String getTaxID() {
    return taxID;
  }

  public void setTaxID(String taxID) {
    this.taxID = taxID;
  }

  public TerminatedRecordMatch businessRegistrationNumber(String businessRegistrationNumber) {
    this.businessRegistrationNumber = businessRegistrationNumber;
    return this;
  }

  /**
   * The indicator of the match type for the data field. N = No Match E = Exact Match P = Partial Match
   * @return businessRegistrationNumber
  **/
  @ApiModelProperty(example = "N", value = "The indicator of the match type for the data field. N = No Match E = Exact Match P = Partial Match")

@Pattern(regexp="([NEP]){1}") 
  public String getBusinessRegistrationNumber() {
    return businessRegistrationNumber;
  }

  public void setBusinessRegistrationNumber(String businessRegistrationNumber) {
    this.businessRegistrationNumber = businessRegistrationNumber;
  }

  public TerminatedRecordMatch financialAcctsMatch(FinancialAcctsMatch financialAcctsMatch) {
    this.financialAcctsMatch = financialAcctsMatch;
    return this;
  }

  /**
   * Get financialAcctsMatch
   * @return financialAcctsMatch
  **/
  @ApiModelProperty(value = "")

  @Valid

  public FinancialAcctsMatch getFinancialAcctsMatch() {
    return financialAcctsMatch;
  }

  public void setFinancialAcctsMatch(FinancialAcctsMatch financialAcctsMatch) {
    this.financialAcctsMatch = financialAcctsMatch;
  }

  public TerminatedRecordMatch principalsMatch(PrincipalsMatch principalsMatch) {
    this.principalsMatch = principalsMatch;
    return this;
  }

  /**
   * Get principalsMatch
   * @return principalsMatch
  **/
  @ApiModelProperty(value = "")

  @Valid

  public PrincipalsMatch getPrincipalsMatch() {
    return principalsMatch;
  }

  public void setPrincipalsMatch(PrincipalsMatch principalsMatch) {
    this.principalsMatch = principalsMatch;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    TerminatedRecordMatch terminatedRecordMatch = (TerminatedRecordMatch) o;
    return Objects.equals(this.dbAName, terminatedRecordMatch.dbAName) &&
        Objects.equals(this.legalName, terminatedRecordMatch.legalName) &&
        Objects.equals(this.addressMatch, terminatedRecordMatch.addressMatch) &&
        Objects.equals(this.businessPhoneNumbers, terminatedRecordMatch.businessPhoneNumbers) &&
        Objects.equals(this.businessEmailAddress, terminatedRecordMatch.businessEmailAddress) &&
        Objects.equals(this.merchantCategoryCodes, terminatedRecordMatch.merchantCategoryCodes) &&
        Objects.equals(this.tradeOverInternet, terminatedRecordMatch.tradeOverInternet) &&
        Objects.equals(this.webAddresses, terminatedRecordMatch.webAddresses) &&
        Objects.equals(this.taxID, terminatedRecordMatch.taxID) &&
        Objects.equals(this.businessRegistrationNumber, terminatedRecordMatch.businessRegistrationNumber) &&
        Objects.equals(this.financialAcctsMatch, terminatedRecordMatch.financialAcctsMatch) &&
        Objects.equals(this.principalsMatch, terminatedRecordMatch.principalsMatch);
  }

  @Override
  public int hashCode() {
    return Objects.hash(dbAName, legalName, addressMatch, businessPhoneNumbers, businessEmailAddress, merchantCategoryCodes, tradeOverInternet, webAddresses, taxID, businessRegistrationNumber, financialAcctsMatch, principalsMatch);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class TerminatedRecordMatch {\n");
    
    sb.append("    dbAName: ").append(toIndentedString(dbAName)).append("\n");
    sb.append("    legalName: ").append(toIndentedString(legalName)).append("\n");
    sb.append("    addressMatch: ").append(toIndentedString(addressMatch)).append("\n");
    sb.append("    businessPhoneNumbers: ").append(toIndentedString(businessPhoneNumbers)).append("\n");
    sb.append("    businessEmailAddress: ").append(toIndentedString(businessEmailAddress)).append("\n");
    sb.append("    merchantCategoryCodes: ").append(toIndentedString(merchantCategoryCodes)).append("\n");
    sb.append("    tradeOverInternet: ").append(toIndentedString(tradeOverInternet)).append("\n");
    sb.append("    webAddresses: ").append(toIndentedString(webAddresses)).append("\n");
    sb.append("    taxID: ").append(toIndentedString(taxID)).append("\n");
    sb.append("    businessRegistrationNumber: ").append(toIndentedString(businessRegistrationNumber)).append("\n");
    sb.append("    financialAcctsMatch: ").append(toIndentedString(financialAcctsMatch)).append("\n");
    sb.append("    principalsMatch: ").append(toIndentedString(principalsMatch)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

