package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.AlertRecords;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * PossibleMatches
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2020-07-02T11:41:02.721Z")

public class PossibleMatches   {
  @JsonProperty("totalAlertCount")
  private Integer totalAlertCount = null;

  @JsonProperty("alertRecords")
  private AlertRecords alertRecords = null;

  public PossibleMatches totalAlertCount(Integer totalAlertCount) {
    this.totalAlertCount = totalAlertCount;
    return this;
  }

  /**
   * Total number of matched records for a retroactive alert.
   * @return totalAlertCount
  **/
  @ApiModelProperty(value = "Total number of matched records for a retroactive alert.")


  public Integer getTotalAlertCount() {
    return totalAlertCount;
  }

  public void setTotalAlertCount(Integer totalAlertCount) {
    this.totalAlertCount = totalAlertCount;
  }

  public PossibleMatches alertRecords(AlertRecords alertRecords) {
    this.alertRecords = alertRecords;
    return this;
  }

  /**
   * Get alertRecords
   * @return alertRecords
  **/
  @ApiModelProperty(value = "")

  @Valid

  public AlertRecords getAlertRecords() {
    return alertRecords;
  }

  public void setAlertRecords(AlertRecords alertRecords) {
    this.alertRecords = alertRecords;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    PossibleMatches possibleMatches = (PossibleMatches) o;
    return Objects.equals(this.totalAlertCount, possibleMatches.totalAlertCount) &&
        Objects.equals(this.alertRecords, possibleMatches.alertRecords);
  }

  @Override
  public int hashCode() {
    return Objects.hash(totalAlertCount, alertRecords);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class PossibleMatches {\n");
    
    sb.append("    totalAlertCount: ").append(toIndentedString(totalAlertCount)).append("\n");
    sb.append("    alertRecords: ").append(toIndentedString(alertRecords)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

