package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.ModifyResponse;
import io.swagger.model.Status;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * ModifyRequestResponse
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2020-07-02T11:23:01.448Z")

public class ModifyRequestResponse   {
  @JsonProperty("status")
  private Status status = null;

  @JsonProperty("modifyResponse")
  private ModifyResponse modifyResponse = null;

  public ModifyRequestResponse status(Status status) {
    this.status = status;
    return this;
  }

  /**
   * Get status
   * @return status
  **/
  @ApiModelProperty(value = "")

  @Valid

  public Status getStatus() {
    return status;
  }

  public void setStatus(Status status) {
    this.status = status;
  }

  public ModifyRequestResponse modifyResponse(ModifyResponse modifyResponse) {
    this.modifyResponse = modifyResponse;
    return this;
  }

  /**
   * Get modifyResponse
   * @return modifyResponse
  **/
  @ApiModelProperty(value = "")

  @Valid

  public ModifyResponse getModifyResponse() {
    return modifyResponse;
  }

  public void setModifyResponse(ModifyResponse modifyResponse) {
    this.modifyResponse = modifyResponse;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ModifyRequestResponse modifyRequestResponse = (ModifyRequestResponse) o;
    return Objects.equals(this.status, modifyRequestResponse.status) &&
        Objects.equals(this.modifyResponse, modifyRequestResponse.modifyResponse);
  }

  @Override
  public int hashCode() {
    return Objects.hash(status, modifyResponse);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ModifyRequestResponse {\n");
    
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    modifyResponse: ").append(toIndentedString(modifyResponse)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

