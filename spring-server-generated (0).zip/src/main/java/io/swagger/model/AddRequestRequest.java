package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.AddRequest;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * AddRequestRequest
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2020-07-02T11:23:01.448Z")

public class AddRequestRequest   {
  @JsonProperty("addRequest")
  private AddRequest addRequest = null;

  public AddRequestRequest addRequest(AddRequest addRequest) {
    this.addRequest = addRequest;
    return this;
  }

  /**
   * Get addRequest
   * @return addRequest
  **/
  @ApiModelProperty(value = "")

  @Valid

  public AddRequest getAddRequest() {
    return addRequest;
  }

  public void setAddRequest(AddRequest addRequest) {
    this.addRequest = addRequest;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    AddRequestRequest addRequestRequest = (AddRequestRequest) o;
    return Objects.equals(this.addRequest, addRequestRequest.addRequest);
  }

  @Override
  public int hashCode() {
    return Objects.hash(addRequest);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class AddRequestRequest {\n");
    
    sb.append("    addRequest: ").append(toIndentedString(addRequest)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

