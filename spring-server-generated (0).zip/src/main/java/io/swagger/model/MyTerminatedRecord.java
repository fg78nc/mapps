package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.TerminatedRecord;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * MyTerminatedRecord
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2020-07-02T11:23:01.448Z")

public class MyTerminatedRecord   {
  @JsonProperty("terminatedRefID")
  private String terminatedRefID = null;

  @JsonProperty("terminatedRecord")
  private TerminatedRecord terminatedRecord = null;

  public MyTerminatedRecord terminatedRefID(String terminatedRefID) {
    this.terminatedRefID = terminatedRefID;
    return this;
  }

  /**
   * A system-generated terminated record reference identification number.
   * @return terminatedRefID
  **/
  @ApiModelProperty(example = "61e8aa42-d252-4e74-9dcc-85134f37a181", value = "A system-generated terminated record reference identification number.")

@Pattern(regexp="^(\\w|\\s|-|,| |\\(|\\)|\\`|\\'|\\.|/|;|:|&|\\$|#|!|\\+|\\?|@|=|\\\\)+$") 
  public String getTerminatedRefID() {
    return terminatedRefID;
  }

  public void setTerminatedRefID(String terminatedRefID) {
    this.terminatedRefID = terminatedRefID;
  }

  public MyTerminatedRecord terminatedRecord(TerminatedRecord terminatedRecord) {
    this.terminatedRecord = terminatedRecord;
    return this;
  }

  /**
   * Get terminatedRecord
   * @return terminatedRecord
  **/
  @ApiModelProperty(value = "")

  @Valid

  public TerminatedRecord getTerminatedRecord() {
    return terminatedRecord;
  }

  public void setTerminatedRecord(TerminatedRecord terminatedRecord) {
    this.terminatedRecord = terminatedRecord;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    MyTerminatedRecord myTerminatedRecord = (MyTerminatedRecord) o;
    return Objects.equals(this.terminatedRefID, myTerminatedRecord.terminatedRefID) &&
        Objects.equals(this.terminatedRecord, myTerminatedRecord.terminatedRecord);
  }

  @Override
  public int hashCode() {
    return Objects.hash(terminatedRefID, terminatedRecord);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class MyTerminatedRecord {\n");
    
    sb.append("    terminatedRefID: ").append(toIndentedString(terminatedRefID)).append("\n");
    sb.append("    terminatedRecord: ").append(toIndentedString(terminatedRecord)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

