package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.MyTerminatedRecords;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * MyTerminatedResponse
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2020-07-02T11:23:01.448Z")

public class MyTerminatedResponse   {
  @JsonProperty("totalCount")
  private Integer totalCount = null;

  @JsonProperty("myTerminatedRecords")
  private MyTerminatedRecords myTerminatedRecords = null;

  public MyTerminatedResponse totalCount(Integer totalCount) {
    this.totalCount = totalCount;
    return this;
  }

  /**
   * Total number of terminated records added by you or a colleague in your organization for the data range requested.
   * @return totalCount
  **/
  @ApiModelProperty(value = "Total number of terminated records added by you or a colleague in your organization for the data range requested.")


  public Integer getTotalCount() {
    return totalCount;
  }

  public void setTotalCount(Integer totalCount) {
    this.totalCount = totalCount;
  }

  public MyTerminatedResponse myTerminatedRecords(MyTerminatedRecords myTerminatedRecords) {
    this.myTerminatedRecords = myTerminatedRecords;
    return this;
  }

  /**
   * Get myTerminatedRecords
   * @return myTerminatedRecords
  **/
  @ApiModelProperty(value = "")

  @Valid

  public MyTerminatedRecords getMyTerminatedRecords() {
    return myTerminatedRecords;
  }

  public void setMyTerminatedRecords(MyTerminatedRecords myTerminatedRecords) {
    this.myTerminatedRecords = myTerminatedRecords;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    MyTerminatedResponse myTerminatedResponse = (MyTerminatedResponse) o;
    return Objects.equals(this.totalCount, myTerminatedResponse.totalCount) &&
        Objects.equals(this.myTerminatedRecords, myTerminatedResponse.myTerminatedRecords);
  }

  @Override
  public int hashCode() {
    return Objects.hash(totalCount, myTerminatedRecords);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class MyTerminatedResponse {\n");
    
    sb.append("    totalCount: ").append(toIndentedString(totalCount)).append("\n");
    sb.append("    myTerminatedRecords: ").append(toIndentedString(myTerminatedRecords)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

