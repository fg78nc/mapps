package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.TerminatedRecord;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * AddResponse
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2020-07-02T11:23:01.448Z")

public class AddResponse   {
  @JsonProperty("action")
  private String action = null;

  @JsonProperty("terminatedRefID")
  private String terminatedRefID = null;

  @JsonProperty("acquirerBID")
  private String acquirerBID = null;

  @JsonProperty("acquirerName")
  private String acquirerName = null;

  @JsonProperty("acquirerCountryOrRegion")
  private String acquirerCountryOrRegion = null;

  @JsonProperty("terminatedRecord")
  private TerminatedRecord terminatedRecord = null;

  public AddResponse action(String action) {
    this.action = action;
    return this;
  }

  /**
   * Action type.
   * @return action
  **/
  @ApiModelProperty(example = "Add", value = "Action type.")

@Pattern(regexp="[\\p{L}\\p{Nd}\\p{Nl}\\p{Z}]*") 
  public String getAction() {
    return action;
  }

  public void setAction(String action) {
    this.action = action;
  }

  public AddResponse terminatedRefID(String terminatedRefID) {
    this.terminatedRefID = terminatedRefID;
    return this;
  }

  /**
   * A system-generated terminated record reference identification number.
   * @return terminatedRefID
  **/
  @ApiModelProperty(example = "61e8aa42-d252-4e74-9dcc-85134f37a181", value = "A system-generated terminated record reference identification number.")

@Pattern(regexp="^(\\w|\\s|-|,| |\\(|\\)|\\`|\\'|\\.|/|;|:|&|\\$|#|!|\\+|\\?|@|=|\\\\)+$") 
  public String getTerminatedRefID() {
    return terminatedRefID;
  }

  public void setTerminatedRefID(String terminatedRefID) {
    this.terminatedRefID = terminatedRefID;
  }

  public AddResponse acquirerBID(String acquirerBID) {
    this.acquirerBID = acquirerBID;
    return this;
  }

  /**
   * Visa assigned Business Identifier (BID) of the Acquirer for the terminated contract.
   * @return acquirerBID
  **/
  @ApiModelProperty(example = "10048640", value = "Visa assigned Business Identifier (BID) of the Acquirer for the terminated contract.")

@Pattern(regexp="\\d{8}") 
  public String getAcquirerBID() {
    return acquirerBID;
  }

  public void setAcquirerBID(String acquirerBID) {
    this.acquirerBID = acquirerBID;
  }

  public AddResponse acquirerName(String acquirerName) {
    this.acquirerName = acquirerName;
    return this;
  }

  /**
   * Name of the Acquirer for the terminated contract.
   * @return acquirerName
  **/
  @ApiModelProperty(example = "Bank of ABC ", value = "Name of the Acquirer for the terminated contract.")

@Pattern(regexp="[\\p{L}\\p{Nd}\\p{Nl}\\p{Z}]*") 
  public String getAcquirerName() {
    return acquirerName;
  }

  public void setAcquirerName(String acquirerName) {
    this.acquirerName = acquirerName;
  }

  public AddResponse acquirerCountryOrRegion(String acquirerCountryOrRegion) {
    this.acquirerCountryOrRegion = acquirerCountryOrRegion;
    return this;
  }

  /**
   * The country or region of the Acquirer for the terminated contract. 
   * @return acquirerCountryOrRegion
  **/
  @ApiModelProperty(example = "JP", value = "The country or region of the Acquirer for the terminated contract. ")

@Pattern(regexp="([A-Z]){2}") 
  public String getAcquirerCountryOrRegion() {
    return acquirerCountryOrRegion;
  }

  public void setAcquirerCountryOrRegion(String acquirerCountryOrRegion) {
    this.acquirerCountryOrRegion = acquirerCountryOrRegion;
  }

  public AddResponse terminatedRecord(TerminatedRecord terminatedRecord) {
    this.terminatedRecord = terminatedRecord;
    return this;
  }

  /**
   * Get terminatedRecord
   * @return terminatedRecord
  **/
  @ApiModelProperty(value = "")

  @Valid

  public TerminatedRecord getTerminatedRecord() {
    return terminatedRecord;
  }

  public void setTerminatedRecord(TerminatedRecord terminatedRecord) {
    this.terminatedRecord = terminatedRecord;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    AddResponse addResponse = (AddResponse) o;
    return Objects.equals(this.action, addResponse.action) &&
        Objects.equals(this.terminatedRefID, addResponse.terminatedRefID) &&
        Objects.equals(this.acquirerBID, addResponse.acquirerBID) &&
        Objects.equals(this.acquirerName, addResponse.acquirerName) &&
        Objects.equals(this.acquirerCountryOrRegion, addResponse.acquirerCountryOrRegion) &&
        Objects.equals(this.terminatedRecord, addResponse.terminatedRecord);
  }

  @Override
  public int hashCode() {
    return Objects.hash(action, terminatedRefID, acquirerBID, acquirerName, acquirerCountryOrRegion, terminatedRecord);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class AddResponse {\n");
    
    sb.append("    action: ").append(toIndentedString(action)).append("\n");
    sb.append("    terminatedRefID: ").append(toIndentedString(terminatedRefID)).append("\n");
    sb.append("    acquirerBID: ").append(toIndentedString(acquirerBID)).append("\n");
    sb.append("    acquirerName: ").append(toIndentedString(acquirerName)).append("\n");
    sb.append("    acquirerCountryOrRegion: ").append(toIndentedString(acquirerCountryOrRegion)).append("\n");
    sb.append("    terminatedRecord: ").append(toIndentedString(terminatedRecord)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

