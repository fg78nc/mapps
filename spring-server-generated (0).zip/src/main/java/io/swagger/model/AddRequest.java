package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.TerminatedRecord;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * AddRequest
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2020-07-02T11:23:01.448Z")

public class AddRequest   {
  @JsonProperty("acquirerBID")
  private String acquirerBID = null;

  @JsonProperty("acquirerCountryOrRegion")
  private String acquirerCountryOrRegion = null;

  @JsonProperty("terminatedRecord")
  private TerminatedRecord terminatedRecord = null;

  public AddRequest acquirerBID(String acquirerBID) {
    this.acquirerBID = acquirerBID;
    return this;
  }

  /**
   * Visa assigned Business Identifier (BID) of the Acquirer for the terminated contract.
   * @return acquirerBID
  **/
  @ApiModelProperty(example = "10048640", value = "Visa assigned Business Identifier (BID) of the Acquirer for the terminated contract.")

@Pattern(regexp="\\d{8}") 
  public String getAcquirerBID() {
    return acquirerBID;
  }

  public void setAcquirerBID(String acquirerBID) {
    this.acquirerBID = acquirerBID;
  }

  public AddRequest acquirerCountryOrRegion(String acquirerCountryOrRegion) {
    this.acquirerCountryOrRegion = acquirerCountryOrRegion;
    return this;
  }

  /**
   * The country or region of the Acquirer for the terminated contract. 
   * @return acquirerCountryOrRegion
  **/
  @ApiModelProperty(example = "JP", value = "The country or region of the Acquirer for the terminated contract. ")

@Pattern(regexp="([A-Z]){2}") 
  public String getAcquirerCountryOrRegion() {
    return acquirerCountryOrRegion;
  }

  public void setAcquirerCountryOrRegion(String acquirerCountryOrRegion) {
    this.acquirerCountryOrRegion = acquirerCountryOrRegion;
  }

  public AddRequest terminatedRecord(TerminatedRecord terminatedRecord) {
    this.terminatedRecord = terminatedRecord;
    return this;
  }

  /**
   * Get terminatedRecord
   * @return terminatedRecord
  **/
  @ApiModelProperty(value = "")

  @Valid

  public TerminatedRecord getTerminatedRecord() {
    return terminatedRecord;
  }

  public void setTerminatedRecord(TerminatedRecord terminatedRecord) {
    this.terminatedRecord = terminatedRecord;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    AddRequest addRequest = (AddRequest) o;
    return Objects.equals(this.acquirerBID, addRequest.acquirerBID) &&
        Objects.equals(this.acquirerCountryOrRegion, addRequest.acquirerCountryOrRegion) &&
        Objects.equals(this.terminatedRecord, addRequest.terminatedRecord);
  }

  @Override
  public int hashCode() {
    return Objects.hash(acquirerBID, acquirerCountryOrRegion, terminatedRecord);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class AddRequest {\n");
    
    sb.append("    acquirerBID: ").append(toIndentedString(acquirerBID)).append("\n");
    sb.append("    acquirerCountryOrRegion: ").append(toIndentedString(acquirerCountryOrRegion)).append("\n");
    sb.append("    terminatedRecord: ").append(toIndentedString(terminatedRecord)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

