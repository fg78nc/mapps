package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.AddResponse;
import io.swagger.model.Status;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * AddRequestResponse
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2020-07-02T11:23:01.448Z")

public class AddRequestResponse   {
  @JsonProperty("status")
  private Status status = null;

  @JsonProperty("addResponse")
  private AddResponse addResponse = null;

  public AddRequestResponse status(Status status) {
    this.status = status;
    return this;
  }

  /**
   * Get status
   * @return status
  **/
  @ApiModelProperty(value = "")

  @Valid

  public Status getStatus() {
    return status;
  }

  public void setStatus(Status status) {
    this.status = status;
  }

  public AddRequestResponse addResponse(AddResponse addResponse) {
    this.addResponse = addResponse;
    return this;
  }

  /**
   * Get addResponse
   * @return addResponse
  **/
  @ApiModelProperty(value = "")

  @Valid

  public AddResponse getAddResponse() {
    return addResponse;
  }

  public void setAddResponse(AddResponse addResponse) {
    this.addResponse = addResponse;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    AddRequestResponse addRequestResponse = (AddRequestResponse) o;
    return Objects.equals(this.status, addRequestResponse.status) &&
        Objects.equals(this.addResponse, addRequestResponse.addResponse);
  }

  @Override
  public int hashCode() {
    return Objects.hash(status, addResponse);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class AddRequestResponse {\n");
    
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    addResponse: ").append(toIndentedString(addResponse)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

