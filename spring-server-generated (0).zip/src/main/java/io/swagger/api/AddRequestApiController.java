package io.swagger.api;

import io.swagger.model.AddRequestRequest;
import io.swagger.model.AddRequestResponse;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.swagger.annotations.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.constraints.*;
import javax.validation.Valid;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.List;
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2020-07-02T11:23:01.448Z")

@Controller
public class AddRequestApiController implements AddRequestApi {

    private static final Logger log = LoggerFactory.getLogger(AddRequestApiController.class);

    private final ObjectMapper objectMapper;

    private final HttpServletRequest request;

    @org.springframework.beans.factory.annotation.Autowired
    public AddRequestApiController(ObjectMapper objectMapper, HttpServletRequest request) {
        this.objectMapper = objectMapper;
        this.request = request;
    }

    public ResponseEntity<AddRequestResponse> addTerminatedMerchantOrAgent(@ApiParam(value = "A user-defined message identifier for the request submitted." ,required=true) @RequestHeader(value="request-message-id", required=true) String requestMessageId,@ApiParam(value = "A user-entered date and timestamp in GMT for the request submitted." ,required=true) @RequestHeader(value="request-message-ts", required=true) String requestMessageTs,@ApiParam(value = "Add Terminated Merchant or Agent" ,required=true )  @Valid @RequestBody AddRequestRequest body,@ApiParam(value = "application/json" ) @RequestHeader(value="Content-Type", required=false) String contentType) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<AddRequestResponse>(objectMapper.readValue("{  \"addResponse\" : {    \"terminatedRefID\" : \"61e8aa42-d252-4e74-9dcc-85134f37a181\",    \"terminatedRecord\" : {      \"acquirerAssignedMerchantID\" : \"36654773\",      \"businessEmailAddress\" : \"billsmith@snapphoto.com\",      \"address\" : {        \"stateOrProvince\" : \"CA\",        \"countryOrRegion\" : \"JP\",        \"streetAddress\" : \"80 Wood Street\",        \"city\" : \"St Albans\",        \"zipOrPostalCode\" : \"SA82GF\"      },      \"incorportationStatus\" : \"3\",      \"paymentFacilitatorCountryOrRegion\" : \"JP\",      \"contractStartDate\" : \"2019-11-01\",      \"contractEndDate\" : \"2019-11-14\",      \"principals\" : \"\",      \"primaryListingReason\" : \"01\",      \"DBAName\" : \"Snap Photoshop Ltd\",      \"legalName\" : \"Snap Photoshop Ltd\",      \"webAddresses\" : [ \"https://u.nu\", \"https://u.nu\" ],      \"tradeInternationally\" : true,      \"financialAccts\" : \"\",      \"secondaryListingReason\" : \"08\",      \"taxID\" : \"GB123456789\",      \"businessRegistrationNumber\" : \"452349600005\",      \"paymentFacilitatorBID\" : \"10000108\",      \"merchantCategoryCodes\" : [ \"5411\", \"5411\" ],      \"tradeOverInternet\" : false,      \"category\" : \"1\",      \"businessPhoneNumbers\" : [ \"+861071111222\", \"+861071111222\" ],      \"cardAcceptorIDs\" : [ \"12345678910111\", \"12345678910111\" ]    },    \"acquirerBID\" : \"10048640\",    \"action\" : \"Add\",    \"acquirerCountryOrRegion\" : \"JP\",    \"acquirerName\" : \"Bank of ABC \"  },  \"status\" : {    \"statusDescription\" : \"Success\",    \"statusCode\" : \"VMSS000\"  }}", AddRequestResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<AddRequestResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<AddRequestResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

}
