package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.Address;
import io.swagger.model.FinancialAccts;
import io.swagger.model.Principals;
import java.util.ArrayList;
import java.util.List;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * TerminatedRecordSearchCriteria
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2020-07-02T11:43:38.078Z")

public class TerminatedRecordSearchCriteria   {
  @JsonProperty("category")
  private String category = null;

  @JsonProperty("DBAName")
  private String dbAName = null;

  @JsonProperty("legalName")
  private String legalName = null;

  @JsonProperty("address")
  private Address address = null;

  @JsonProperty("businessPhoneNumbers")
  @Valid
  private List<String> businessPhoneNumbers = null;

  @JsonProperty("businessEmailAddress")
  private String businessEmailAddress = null;

  @JsonProperty("merchantCategoryCodes")
  @Valid
  private List<String> merchantCategoryCodes = null;

  @JsonProperty("tradeOverInternet")
  private Boolean tradeOverInternet = false;

  @JsonProperty("webAddresses")
  @Valid
  private List<String> webAddresses = null;

  @JsonProperty("taxID")
  private String taxID = null;

  @JsonProperty("businessRegistrationNumber")
  private String businessRegistrationNumber = null;

  @JsonProperty("financialAccts")
  private FinancialAccts financialAccts = null;

  @JsonProperty("principals")
  private Principals principals = null;

  public TerminatedRecordSearchCriteria category(String category) {
    this.category = category;
    return this;
  }

  /**
   * Business Category of the Terminated Record defined as follows: 0 = Merchant 1 = Payment Facilitator 2 = Independent Sales Organization 3 = Marketplace 4 = Staged Digital Wallet Operator 5 = Sponsored Merchant
   * @return category
  **/
  @ApiModelProperty(example = "1", required = true, value = "Business Category of the Terminated Record defined as follows: 0 = Merchant 1 = Payment Facilitator 2 = Independent Sales Organization 3 = Marketplace 4 = Staged Digital Wallet Operator 5 = Sponsored Merchant")
  @NotNull

@Pattern(regexp="[0-5]") 
  public String getCategory() {
    return category;
  }

  public void setCategory(String category) {
    this.category = category;
  }

  public TerminatedRecordSearchCriteria dbAName(String dbAName) {
    this.dbAName = dbAName;
    return this;
  }

  /**
   * The “Doing-Business-As” Name that the merchant or agent operates under.
   * @return dbAName
  **/
  @ApiModelProperty(example = "Snap Photoshop Ltd", required = true, value = "The “Doing-Business-As” Name that the merchant or agent operates under.")
  @NotNull

@Pattern(regexp="^(\\w|\\s|-|,|�|\\(|\\)|\\`|\\'|\\.|/|;|:|&|\\$|#|!|\\+|\\?|@|=|\\\\)+$") 
  public String getDbAName() {
    return dbAName;
  }

  public void setDbAName(String dbAName) {
    this.dbAName = dbAName;
  }

  public TerminatedRecordSearchCriteria legalName(String legalName) {
    this.legalName = legalName;
    return this;
  }

  /**
   * The parent or holding company legally registered name if this name is different from the Trading Name/DBA Name. For a sole proprietor, this field shall be omitted.
   * @return legalName
  **/
  @ApiModelProperty(example = "Snap Photoshop Ltd", value = "The parent or holding company legally registered name if this name is different from the Trading Name/DBA Name. For a sole proprietor, this field shall be omitted.")

@Pattern(regexp="^(\\w|\\s|-|,|�|\\(|\\)|\\`|\\'|\\.|/|;|:|&|\\$|#|!|\\+|\\?|@|=|\\\\)+$") 
  public String getLegalName() {
    return legalName;
  }

  public void setLegalName(String legalName) {
    this.legalName = legalName;
  }

  public TerminatedRecordSearchCriteria address(Address address) {
    this.address = address;
    return this;
  }

  /**
   * Get address
   * @return address
  **/
  @ApiModelProperty(required = true, value = "")
  @NotNull

  @Valid

  public Address getAddress() {
    return address;
  }

  public void setAddress(Address address) {
    this.address = address;
  }

  public TerminatedRecordSearchCriteria businessPhoneNumbers(List<String> businessPhoneNumbers) {
    this.businessPhoneNumbers = businessPhoneNumbers;
    return this;
  }

  public TerminatedRecordSearchCriteria addBusinessPhoneNumbersItem(String businessPhoneNumbersItem) {
    if (this.businessPhoneNumbers == null) {
      this.businessPhoneNumbers = new ArrayList<String>();
    }
    this.businessPhoneNumbers.add(businessPhoneNumbersItem);
    return this;
  }

  /**
   * Get businessPhoneNumbers
   * @return businessPhoneNumbers
  **/
  @ApiModelProperty(value = "")


  public List<String> getBusinessPhoneNumbers() {
    return businessPhoneNumbers;
  }

  public void setBusinessPhoneNumbers(List<String> businessPhoneNumbers) {
    this.businessPhoneNumbers = businessPhoneNumbers;
  }

  public TerminatedRecordSearchCriteria businessEmailAddress(String businessEmailAddress) {
    this.businessEmailAddress = businessEmailAddress;
    return this;
  }

  /**
   * The primary email address registered for the merchant or agent.
   * @return businessEmailAddress
  **/
  @ApiModelProperty(example = "billsmith@snapphoto.com", value = "The primary email address registered for the merchant or agent.")

@Pattern(regexp="[A-Za-z0-9._%-]+@[A-Za-z0-9.-]+\\.[a-zA-Z]{2,4}$") 
  public String getBusinessEmailAddress() {
    return businessEmailAddress;
  }

  public void setBusinessEmailAddress(String businessEmailAddress) {
    this.businessEmailAddress = businessEmailAddress;
  }

  public TerminatedRecordSearchCriteria merchantCategoryCodes(List<String> merchantCategoryCodes) {
    this.merchantCategoryCodes = merchantCategoryCodes;
    return this;
  }

  public TerminatedRecordSearchCriteria addMerchantCategoryCodesItem(String merchantCategoryCodesItem) {
    if (this.merchantCategoryCodes == null) {
      this.merchantCategoryCodes = new ArrayList<String>();
    }
    this.merchantCategoryCodes.add(merchantCategoryCodesItem);
    return this;
  }

  /**
   * Get merchantCategoryCodes
   * @return merchantCategoryCodes
  **/
  @ApiModelProperty(value = "")


  public List<String> getMerchantCategoryCodes() {
    return merchantCategoryCodes;
  }

  public void setMerchantCategoryCodes(List<String> merchantCategoryCodes) {
    this.merchantCategoryCodes = merchantCategoryCodes;
  }

  public TerminatedRecordSearchCriteria tradeOverInternet(Boolean tradeOverInternet) {
    this.tradeOverInternet = tradeOverInternet;
    return this;
  }

  /**
   * An indicator identifying if the merchant or agent trades over the Internet.
   * @return tradeOverInternet
  **/
  @ApiModelProperty(example = "false", required = true, value = "An indicator identifying if the merchant or agent trades over the Internet.")
  @NotNull


  public Boolean isTradeOverInternet() {
    return tradeOverInternet;
  }

  public void setTradeOverInternet(Boolean tradeOverInternet) {
    this.tradeOverInternet = tradeOverInternet;
  }

  public TerminatedRecordSearchCriteria webAddresses(List<String> webAddresses) {
    this.webAddresses = webAddresses;
    return this;
  }

  public TerminatedRecordSearchCriteria addWebAddressesItem(String webAddressesItem) {
    if (this.webAddresses == null) {
      this.webAddresses = new ArrayList<String>();
    }
    this.webAddresses.add(webAddressesItem);
    return this;
  }

  /**
   * Get webAddresses
   * @return webAddresses
  **/
  @ApiModelProperty(value = "")


  public List<String> getWebAddresses() {
    return webAddresses;
  }

  public void setWebAddresses(List<String> webAddresses) {
    this.webAddresses = webAddresses;
  }

  public TerminatedRecordSearchCriteria taxID(String taxID) {
    this.taxID = taxID;
    return this;
  }

  /**
   * A Tax Identification Code registered for the merchant or agent; for example, a Value Added Tax (VAT) Number in the UK or a Federal Tax ID Number in US.
   * @return taxID
  **/
  @ApiModelProperty(example = "GB123456789", value = "A Tax Identification Code registered for the merchant or agent; for example, a Value Added Tax (VAT) Number in the UK or a Federal Tax ID Number in US.")

@Pattern(regexp="[\\p{L}\\p{Nd}\\p{Nl}\\p{Z}]*") 
  public String getTaxID() {
    return taxID;
  }

  public void setTaxID(String taxID) {
    this.taxID = taxID;
  }

  public TerminatedRecordSearchCriteria businessRegistrationNumber(String businessRegistrationNumber) {
    this.businessRegistrationNumber = businessRegistrationNumber;
    return this;
  }

  /**
   * A Business Registration Number such as Commercial Registration, Ministry of Commerce certificate number or equivalent registration number for the merchant or agent that does not have a tax ID.
   * @return businessRegistrationNumber
  **/
  @ApiModelProperty(example = "452349600005", value = "A Business Registration Number such as Commercial Registration, Ministry of Commerce certificate number or equivalent registration number for the merchant or agent that does not have a tax ID.")

@Pattern(regexp="[\\p{L}\\p{Nd}\\p{Nl}\\p{Z}]*") 
  public String getBusinessRegistrationNumber() {
    return businessRegistrationNumber;
  }

  public void setBusinessRegistrationNumber(String businessRegistrationNumber) {
    this.businessRegistrationNumber = businessRegistrationNumber;
  }

  public TerminatedRecordSearchCriteria financialAccts(FinancialAccts financialAccts) {
    this.financialAccts = financialAccts;
    return this;
  }

  /**
   * Get financialAccts
   * @return financialAccts
  **/
  @ApiModelProperty(value = "")

  @Valid

  public FinancialAccts getFinancialAccts() {
    return financialAccts;
  }

  public void setFinancialAccts(FinancialAccts financialAccts) {
    this.financialAccts = financialAccts;
  }

  public TerminatedRecordSearchCriteria principals(Principals principals) {
    this.principals = principals;
    return this;
  }

  /**
   * Get principals
   * @return principals
  **/
  @ApiModelProperty(value = "")

  @Valid

  public Principals getPrincipals() {
    return principals;
  }

  public void setPrincipals(Principals principals) {
    this.principals = principals;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    TerminatedRecordSearchCriteria terminatedRecordSearchCriteria = (TerminatedRecordSearchCriteria) o;
    return Objects.equals(this.category, terminatedRecordSearchCriteria.category) &&
        Objects.equals(this.dbAName, terminatedRecordSearchCriteria.dbAName) &&
        Objects.equals(this.legalName, terminatedRecordSearchCriteria.legalName) &&
        Objects.equals(this.address, terminatedRecordSearchCriteria.address) &&
        Objects.equals(this.businessPhoneNumbers, terminatedRecordSearchCriteria.businessPhoneNumbers) &&
        Objects.equals(this.businessEmailAddress, terminatedRecordSearchCriteria.businessEmailAddress) &&
        Objects.equals(this.merchantCategoryCodes, terminatedRecordSearchCriteria.merchantCategoryCodes) &&
        Objects.equals(this.tradeOverInternet, terminatedRecordSearchCriteria.tradeOverInternet) &&
        Objects.equals(this.webAddresses, terminatedRecordSearchCriteria.webAddresses) &&
        Objects.equals(this.taxID, terminatedRecordSearchCriteria.taxID) &&
        Objects.equals(this.businessRegistrationNumber, terminatedRecordSearchCriteria.businessRegistrationNumber) &&
        Objects.equals(this.financialAccts, terminatedRecordSearchCriteria.financialAccts) &&
        Objects.equals(this.principals, terminatedRecordSearchCriteria.principals);
  }

  @Override
  public int hashCode() {
    return Objects.hash(category, dbAName, legalName, address, businessPhoneNumbers, businessEmailAddress, merchantCategoryCodes, tradeOverInternet, webAddresses, taxID, businessRegistrationNumber, financialAccts, principals);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class TerminatedRecordSearchCriteria {\n");
    
    sb.append("    category: ").append(toIndentedString(category)).append("\n");
    sb.append("    dbAName: ").append(toIndentedString(dbAName)).append("\n");
    sb.append("    legalName: ").append(toIndentedString(legalName)).append("\n");
    sb.append("    address: ").append(toIndentedString(address)).append("\n");
    sb.append("    businessPhoneNumbers: ").append(toIndentedString(businessPhoneNumbers)).append("\n");
    sb.append("    businessEmailAddress: ").append(toIndentedString(businessEmailAddress)).append("\n");
    sb.append("    merchantCategoryCodes: ").append(toIndentedString(merchantCategoryCodes)).append("\n");
    sb.append("    tradeOverInternet: ").append(toIndentedString(tradeOverInternet)).append("\n");
    sb.append("    webAddresses: ").append(toIndentedString(webAddresses)).append("\n");
    sb.append("    taxID: ").append(toIndentedString(taxID)).append("\n");
    sb.append("    businessRegistrationNumber: ").append(toIndentedString(businessRegistrationNumber)).append("\n");
    sb.append("    financialAccts: ").append(toIndentedString(financialAccts)).append("\n");
    sb.append("    principals: ").append(toIndentedString(principals)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

