package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * AddressMatch
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2020-07-02T11:43:38.078Z")

public class AddressMatch   {
  @JsonProperty("streetAddress")
  private String streetAddress = null;

  @JsonProperty("city")
  private String city = null;

  @JsonProperty("stateOrProvince")
  private String stateOrProvince = null;

  @JsonProperty("zipOrPostalCode")
  private String zipOrPostalCode = null;

  @JsonProperty("countryOrRegion")
  private String countryOrRegion = null;

  public AddressMatch streetAddress(String streetAddress) {
    this.streetAddress = streetAddress;
    return this;
  }

  /**
   * The indicator of the match type for the data field. N = No Match E = Exact Match P = Partial Match
   * @return streetAddress
  **/
  @ApiModelProperty(example = "N", value = "The indicator of the match type for the data field. N = No Match E = Exact Match P = Partial Match")

@Pattern(regexp="([NEP]){1}") 
  public String getStreetAddress() {
    return streetAddress;
  }

  public void setStreetAddress(String streetAddress) {
    this.streetAddress = streetAddress;
  }

  public AddressMatch city(String city) {
    this.city = city;
    return this;
  }

  /**
   * The indicator of the match type for the data field. N = No Match E = Exact Match P = Partial Match
   * @return city
  **/
  @ApiModelProperty(example = "N", value = "The indicator of the match type for the data field. N = No Match E = Exact Match P = Partial Match")

@Pattern(regexp="([NEP]){1}") 
  public String getCity() {
    return city;
  }

  public void setCity(String city) {
    this.city = city;
  }

  public AddressMatch stateOrProvince(String stateOrProvince) {
    this.stateOrProvince = stateOrProvince;
    return this;
  }

  /**
   * The indicator of the match type for the data field. N = No Match E = Exact Match P = Partial Match
   * @return stateOrProvince
  **/
  @ApiModelProperty(example = "N", value = "The indicator of the match type for the data field. N = No Match E = Exact Match P = Partial Match")

@Pattern(regexp="([NEP]){1}") 
  public String getStateOrProvince() {
    return stateOrProvince;
  }

  public void setStateOrProvince(String stateOrProvince) {
    this.stateOrProvince = stateOrProvince;
  }

  public AddressMatch zipOrPostalCode(String zipOrPostalCode) {
    this.zipOrPostalCode = zipOrPostalCode;
    return this;
  }

  /**
   * The indicator of the match type for the data field. N = No Match E = Exact Match P = Partial Match
   * @return zipOrPostalCode
  **/
  @ApiModelProperty(example = "N", value = "The indicator of the match type for the data field. N = No Match E = Exact Match P = Partial Match")

@Pattern(regexp="([NEP]){1}") 
  public String getZipOrPostalCode() {
    return zipOrPostalCode;
  }

  public void setZipOrPostalCode(String zipOrPostalCode) {
    this.zipOrPostalCode = zipOrPostalCode;
  }

  public AddressMatch countryOrRegion(String countryOrRegion) {
    this.countryOrRegion = countryOrRegion;
    return this;
  }

  /**
   * The indicator of the match type for the data field. N = No Match E = Exact Match P = Partial Match
   * @return countryOrRegion
  **/
  @ApiModelProperty(example = "N", value = "The indicator of the match type for the data field. N = No Match E = Exact Match P = Partial Match")

@Pattern(regexp="([NEP]){1}") 
  public String getCountryOrRegion() {
    return countryOrRegion;
  }

  public void setCountryOrRegion(String countryOrRegion) {
    this.countryOrRegion = countryOrRegion;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    AddressMatch addressMatch = (AddressMatch) o;
    return Objects.equals(this.streetAddress, addressMatch.streetAddress) &&
        Objects.equals(this.city, addressMatch.city) &&
        Objects.equals(this.stateOrProvince, addressMatch.stateOrProvince) &&
        Objects.equals(this.zipOrPostalCode, addressMatch.zipOrPostalCode) &&
        Objects.equals(this.countryOrRegion, addressMatch.countryOrRegion);
  }

  @Override
  public int hashCode() {
    return Objects.hash(streetAddress, city, stateOrProvince, zipOrPostalCode, countryOrRegion);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class AddressMatch {\n");
    
    sb.append("    streetAddress: ").append(toIndentedString(streetAddress)).append("\n");
    sb.append("    city: ").append(toIndentedString(city)).append("\n");
    sb.append("    stateOrProvince: ").append(toIndentedString(stateOrProvince)).append("\n");
    sb.append("    zipOrPostalCode: ").append(toIndentedString(zipOrPostalCode)).append("\n");
    sb.append("    countryOrRegion: ").append(toIndentedString(countryOrRegion)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

