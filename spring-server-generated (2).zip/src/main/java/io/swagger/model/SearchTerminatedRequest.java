package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.TerminatedRecordSearchCriteria;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * SearchTerminatedRequest
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2020-07-02T11:43:38.078Z")

public class SearchTerminatedRequest   {
  @JsonProperty("retroAlertIfNoMatch")
  private Boolean retroAlertIfNoMatch = false;

  @JsonProperty("acquirerBID")
  private String acquirerBID = null;

  @JsonProperty("acquirerCountryOrRegion")
  private String acquirerCountryOrRegion = null;

  @JsonProperty("globalSearch")
  private Boolean globalSearch = false;

  @JsonProperty("terminatedRecordSearchCriteria")
  private TerminatedRecordSearchCriteria terminatedRecordSearchCriteria = null;

  public SearchTerminatedRequest retroAlertIfNoMatch(Boolean retroAlertIfNoMatch) {
    this.retroAlertIfNoMatch = retroAlertIfNoMatch;
    return this;
  }

  /**
   * Add an alert so that VMSS saves the inquiry for 180 days and checks the inquiry against all new terminated records that are listed within the next 180 days. If your inquiry matches a new terminated record, VMSS will generate a retroactive alert. 
   * @return retroAlertIfNoMatch
  **/
  @ApiModelProperty(example = "false", value = "Add an alert so that VMSS saves the inquiry for 180 days and checks the inquiry against all new terminated records that are listed within the next 180 days. If your inquiry matches a new terminated record, VMSS will generate a retroactive alert. ")


  public Boolean isRetroAlertIfNoMatch() {
    return retroAlertIfNoMatch;
  }

  public void setRetroAlertIfNoMatch(Boolean retroAlertIfNoMatch) {
    this.retroAlertIfNoMatch = retroAlertIfNoMatch;
  }

  public SearchTerminatedRequest acquirerBID(String acquirerBID) {
    this.acquirerBID = acquirerBID;
    return this;
  }

  /**
   * Visa assigned Business Identifier (BID) of the Acquirer for the Search request.
   * @return acquirerBID
  **/
  @ApiModelProperty(example = "10048640", value = "Visa assigned Business Identifier (BID) of the Acquirer for the Search request.")

@Pattern(regexp="\\d{8}") 
  public String getAcquirerBID() {
    return acquirerBID;
  }

  public void setAcquirerBID(String acquirerBID) {
    this.acquirerBID = acquirerBID;
  }

  public SearchTerminatedRequest acquirerCountryOrRegion(String acquirerCountryOrRegion) {
    this.acquirerCountryOrRegion = acquirerCountryOrRegion;
    return this;
  }

  /**
   * The country or region of the Acquirer for the Search request.
   * @return acquirerCountryOrRegion
  **/
  @ApiModelProperty(example = "JP", value = "The country or region of the Acquirer for the Search request.")

@Pattern(regexp="([A-Z]){2}") 
  public String getAcquirerCountryOrRegion() {
    return acquirerCountryOrRegion;
  }

  public void setAcquirerCountryOrRegion(String acquirerCountryOrRegion) {
    this.acquirerCountryOrRegion = acquirerCountryOrRegion;
  }

  public SearchTerminatedRequest globalSearch(Boolean globalSearch) {
    this.globalSearch = globalSearch;
    return this;
  }

  /**
   * An indicator identifying if the inquiry is worldwide or regional based. True means Global Search and False means Regional Search.
   * @return globalSearch
  **/
  @ApiModelProperty(example = "false", value = "An indicator identifying if the inquiry is worldwide or regional based. True means Global Search and False means Regional Search.")


  public Boolean isGlobalSearch() {
    return globalSearch;
  }

  public void setGlobalSearch(Boolean globalSearch) {
    this.globalSearch = globalSearch;
  }

  public SearchTerminatedRequest terminatedRecordSearchCriteria(TerminatedRecordSearchCriteria terminatedRecordSearchCriteria) {
    this.terminatedRecordSearchCriteria = terminatedRecordSearchCriteria;
    return this;
  }

  /**
   * Get terminatedRecordSearchCriteria
   * @return terminatedRecordSearchCriteria
  **/
  @ApiModelProperty(value = "")

  @Valid

  public TerminatedRecordSearchCriteria getTerminatedRecordSearchCriteria() {
    return terminatedRecordSearchCriteria;
  }

  public void setTerminatedRecordSearchCriteria(TerminatedRecordSearchCriteria terminatedRecordSearchCriteria) {
    this.terminatedRecordSearchCriteria = terminatedRecordSearchCriteria;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    SearchTerminatedRequest searchTerminatedRequest = (SearchTerminatedRequest) o;
    return Objects.equals(this.retroAlertIfNoMatch, searchTerminatedRequest.retroAlertIfNoMatch) &&
        Objects.equals(this.acquirerBID, searchTerminatedRequest.acquirerBID) &&
        Objects.equals(this.acquirerCountryOrRegion, searchTerminatedRequest.acquirerCountryOrRegion) &&
        Objects.equals(this.globalSearch, searchTerminatedRequest.globalSearch) &&
        Objects.equals(this.terminatedRecordSearchCriteria, searchTerminatedRequest.terminatedRecordSearchCriteria);
  }

  @Override
  public int hashCode() {
    return Objects.hash(retroAlertIfNoMatch, acquirerBID, acquirerCountryOrRegion, globalSearch, terminatedRecordSearchCriteria);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class SearchTerminatedRequest {\n");
    
    sb.append("    retroAlertIfNoMatch: ").append(toIndentedString(retroAlertIfNoMatch)).append("\n");
    sb.append("    acquirerBID: ").append(toIndentedString(acquirerBID)).append("\n");
    sb.append("    acquirerCountryOrRegion: ").append(toIndentedString(acquirerCountryOrRegion)).append("\n");
    sb.append("    globalSearch: ").append(toIndentedString(globalSearch)).append("\n");
    sb.append("    terminatedRecordSearchCriteria: ").append(toIndentedString(terminatedRecordSearchCriteria)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

