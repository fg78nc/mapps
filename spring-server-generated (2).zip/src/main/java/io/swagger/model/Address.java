package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * Address
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2020-07-02T11:43:38.078Z")

public class Address   {
  @JsonProperty("streetAddress")
  private String streetAddress = null;

  @JsonProperty("city")
  private String city = null;

  @JsonProperty("stateOrProvince")
  private String stateOrProvince = null;

  @JsonProperty("zipOrPostalCode")
  private String zipOrPostalCode = null;

  @JsonProperty("countryOrRegion")
  private String countryOrRegion = null;

  public Address streetAddress(String streetAddress) {
    this.streetAddress = streetAddress;
    return this;
  }

  /**
   * The street details of the merchant's or agent's registered address that should include, in this order as applicable: building number/name, street number and name, shop number, floor number.
   * @return streetAddress
  **/
  @ApiModelProperty(example = "80 Wood Street", required = true, value = "The street details of the merchant's or agent's registered address that should include, in this order as applicable: building number/name, street number and name, shop number, floor number.")
  @NotNull

@Pattern(regexp="[\\p{L}\\p{Nd}\\p{Nl}\\p{Z}]*") 
  public String getStreetAddress() {
    return streetAddress;
  }

  public void setStreetAddress(String streetAddress) {
    this.streetAddress = streetAddress;
  }

  public Address city(String city) {
    this.city = city;
    return this;
  }

  /**
   * The city of the merchant's or agent's registered address.
   * @return city
  **/
  @ApiModelProperty(example = "St Albans", required = true, value = "The city of the merchant's or agent's registered address.")
  @NotNull

@Pattern(regexp="[\\p{L}\\p{Nd}\\p{Nl}\\p{Z}]*") 
  public String getCity() {
    return city;
  }

  public void setCity(String city) {
    this.city = city;
  }

  public Address stateOrProvince(String stateOrProvince) {
    this.stateOrProvince = stateOrProvince;
    return this;
  }

  /**
   * The state or province of the merchant's or agent's registered address.
   * @return stateOrProvince
  **/
  @ApiModelProperty(example = "CA", value = "The state or province of the merchant's or agent's registered address.")

@Pattern(regexp="[\\p{L}\\p{Nd}\\p{Nl}\\p{Z}]*") 
  public String getStateOrProvince() {
    return stateOrProvince;
  }

  public void setStateOrProvince(String stateOrProvince) {
    this.stateOrProvince = stateOrProvince;
  }

  public Address zipOrPostalCode(String zipOrPostalCode) {
    this.zipOrPostalCode = zipOrPostalCode;
    return this;
  }

  /**
   * The postal code or zip code for the merchant's or agent's registered address.
   * @return zipOrPostalCode
  **/
  @ApiModelProperty(example = "SA82GF", value = "The postal code or zip code for the merchant's or agent's registered address.")

@Pattern(regexp="[\\p{L}\\p{Nd}\\p{Nl}\\p{Z}]*") 
  public String getZipOrPostalCode() {
    return zipOrPostalCode;
  }

  public void setZipOrPostalCode(String zipOrPostalCode) {
    this.zipOrPostalCode = zipOrPostalCode;
  }

  public Address countryOrRegion(String countryOrRegion) {
    this.countryOrRegion = countryOrRegion;
    return this;
  }

  /**
   * The country or region of the merchant's or agent's registered address.
   * @return countryOrRegion
  **/
  @ApiModelProperty(example = "JP", required = true, value = "The country or region of the merchant's or agent's registered address.")
  @NotNull

@Pattern(regexp="([A-Z]){2}") 
  public String getCountryOrRegion() {
    return countryOrRegion;
  }

  public void setCountryOrRegion(String countryOrRegion) {
    this.countryOrRegion = countryOrRegion;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Address address = (Address) o;
    return Objects.equals(this.streetAddress, address.streetAddress) &&
        Objects.equals(this.city, address.city) &&
        Objects.equals(this.stateOrProvince, address.stateOrProvince) &&
        Objects.equals(this.zipOrPostalCode, address.zipOrPostalCode) &&
        Objects.equals(this.countryOrRegion, address.countryOrRegion);
  }

  @Override
  public int hashCode() {
    return Objects.hash(streetAddress, city, stateOrProvince, zipOrPostalCode, countryOrRegion);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Address {\n");
    
    sb.append("    streetAddress: ").append(toIndentedString(streetAddress)).append("\n");
    sb.append("    city: ").append(toIndentedString(city)).append("\n");
    sb.append("    stateOrProvince: ").append(toIndentedString(stateOrProvince)).append("\n");
    sb.append("    zipOrPostalCode: ").append(toIndentedString(zipOrPostalCode)).append("\n");
    sb.append("    countryOrRegion: ").append(toIndentedString(countryOrRegion)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

