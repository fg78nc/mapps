package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.MatchedRecords;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * PossibleMatches
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2020-07-02T11:43:38.078Z")

public class PossibleMatches   {
  @JsonProperty("totalCount")
  private Integer totalCount = null;

  @JsonProperty("matchedRecords")
  private MatchedRecords matchedRecords = null;

  public PossibleMatches totalCount(Integer totalCount) {
    this.totalCount = totalCount;
    return this;
  }

  /**
   * Number of possibly matched records returned in the response.
   * @return totalCount
  **/
  @ApiModelProperty(value = "Number of possibly matched records returned in the response.")


  public Integer getTotalCount() {
    return totalCount;
  }

  public void setTotalCount(Integer totalCount) {
    this.totalCount = totalCount;
  }

  public PossibleMatches matchedRecords(MatchedRecords matchedRecords) {
    this.matchedRecords = matchedRecords;
    return this;
  }

  /**
   * Get matchedRecords
   * @return matchedRecords
  **/
  @ApiModelProperty(value = "")

  @Valid

  public MatchedRecords getMatchedRecords() {
    return matchedRecords;
  }

  public void setMatchedRecords(MatchedRecords matchedRecords) {
    this.matchedRecords = matchedRecords;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    PossibleMatches possibleMatches = (PossibleMatches) o;
    return Objects.equals(this.totalCount, possibleMatches.totalCount) &&
        Objects.equals(this.matchedRecords, possibleMatches.matchedRecords);
  }

  @Override
  public int hashCode() {
    return Objects.hash(totalCount, matchedRecords);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class PossibleMatches {\n");
    
    sb.append("    totalCount: ").append(toIndentedString(totalCount)).append("\n");
    sb.append("    matchedRecords: ").append(toIndentedString(matchedRecords)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

