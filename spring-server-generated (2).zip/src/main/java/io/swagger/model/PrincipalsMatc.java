package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * PrincipalsMatc
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2020-07-02T11:43:38.078Z")

public class PrincipalsMatc   {
  @JsonProperty("name")
  private String name = null;

  @JsonProperty("businessPhoneNumber")
  private String businessPhoneNumber = null;

  @JsonProperty("businessEmailAddress")
  private String businessEmailAddress = null;

  @JsonProperty("principalID")
  private String principalID = null;

  @JsonProperty("SSN")
  private String SSN = null;

  @JsonProperty("driverLicenseNumber")
  private String driverLicenseNumber = null;

  @JsonProperty("residentIDOrNationalID")
  private String residentIDOrNationalID = null;

  @JsonProperty("passportNumber")
  private String passportNumber = null;

  public PrincipalsMatc name(String name) {
    this.name = name;
    return this;
  }

  /**
   * The indicator of the match type for the data field. N = No Match E = Exact Match P = Partial Match
   * @return name
  **/
  @ApiModelProperty(example = "N", value = "The indicator of the match type for the data field. N = No Match E = Exact Match P = Partial Match")

@Pattern(regexp="([NEP]){1}") 
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public PrincipalsMatc businessPhoneNumber(String businessPhoneNumber) {
    this.businessPhoneNumber = businessPhoneNumber;
    return this;
  }

  /**
   * The indicator of the match type for the data field. N = No Match E = Exact Match P = Partial Match
   * @return businessPhoneNumber
  **/
  @ApiModelProperty(example = "N", value = "The indicator of the match type for the data field. N = No Match E = Exact Match P = Partial Match")

@Pattern(regexp="([NEP]){1}") 
  public String getBusinessPhoneNumber() {
    return businessPhoneNumber;
  }

  public void setBusinessPhoneNumber(String businessPhoneNumber) {
    this.businessPhoneNumber = businessPhoneNumber;
  }

  public PrincipalsMatc businessEmailAddress(String businessEmailAddress) {
    this.businessEmailAddress = businessEmailAddress;
    return this;
  }

  /**
   * The indicator of the match type for the data field. N = No Match E = Exact Match P = Partial Match
   * @return businessEmailAddress
  **/
  @ApiModelProperty(example = "N", value = "The indicator of the match type for the data field. N = No Match E = Exact Match P = Partial Match")

@Pattern(regexp="([NEP]){1}") 
  public String getBusinessEmailAddress() {
    return businessEmailAddress;
  }

  public void setBusinessEmailAddress(String businessEmailAddress) {
    this.businessEmailAddress = businessEmailAddress;
  }

  public PrincipalsMatc principalID(String principalID) {
    this.principalID = principalID;
    return this;
  }

  /**
   * The indicator of the match type for the data field. N = No Match E = Exact Match P = Partial Match
   * @return principalID
  **/
  @ApiModelProperty(example = "N", value = "The indicator of the match type for the data field. N = No Match E = Exact Match P = Partial Match")

@Pattern(regexp="([NEP]){1}") 
  public String getPrincipalID() {
    return principalID;
  }

  public void setPrincipalID(String principalID) {
    this.principalID = principalID;
  }

  public PrincipalsMatc SSN(String SSN) {
    this.SSN = SSN;
    return this;
  }

  /**
   * The indicator of the match type for the data field. N = No Match E = Exact Match P = Partial Match
   * @return SSN
  **/
  @ApiModelProperty(example = "N", value = "The indicator of the match type for the data field. N = No Match E = Exact Match P = Partial Match")

@Pattern(regexp="([NEP]){1}") 
  public String getSSN() {
    return SSN;
  }

  public void setSSN(String SSN) {
    this.SSN = SSN;
  }

  public PrincipalsMatc driverLicenseNumber(String driverLicenseNumber) {
    this.driverLicenseNumber = driverLicenseNumber;
    return this;
  }

  /**
   * The indicator of the match type for the data field. N = No Match E = Exact Match P = Partial Match
   * @return driverLicenseNumber
  **/
  @ApiModelProperty(example = "N", value = "The indicator of the match type for the data field. N = No Match E = Exact Match P = Partial Match")

@Pattern(regexp="([NEP]){1}") 
  public String getDriverLicenseNumber() {
    return driverLicenseNumber;
  }

  public void setDriverLicenseNumber(String driverLicenseNumber) {
    this.driverLicenseNumber = driverLicenseNumber;
  }

  public PrincipalsMatc residentIDOrNationalID(String residentIDOrNationalID) {
    this.residentIDOrNationalID = residentIDOrNationalID;
    return this;
  }

  /**
   * The indicator of the match type for the data field. N = No Match E = Exact Match P = Partial Match
   * @return residentIDOrNationalID
  **/
  @ApiModelProperty(example = "N", value = "The indicator of the match type for the data field. N = No Match E = Exact Match P = Partial Match")

@Pattern(regexp="([NEP]){1}") 
  public String getResidentIDOrNationalID() {
    return residentIDOrNationalID;
  }

  public void setResidentIDOrNationalID(String residentIDOrNationalID) {
    this.residentIDOrNationalID = residentIDOrNationalID;
  }

  public PrincipalsMatc passportNumber(String passportNumber) {
    this.passportNumber = passportNumber;
    return this;
  }

  /**
   * The indicator of the match type for the data field. N = No Match E = Exact Match P = Partial Match
   * @return passportNumber
  **/
  @ApiModelProperty(example = "N", value = "The indicator of the match type for the data field. N = No Match E = Exact Match P = Partial Match")

@Pattern(regexp="([NEP]){1}") 
  public String getPassportNumber() {
    return passportNumber;
  }

  public void setPassportNumber(String passportNumber) {
    this.passportNumber = passportNumber;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    PrincipalsMatc principalsMatc = (PrincipalsMatc) o;
    return Objects.equals(this.name, principalsMatc.name) &&
        Objects.equals(this.businessPhoneNumber, principalsMatc.businessPhoneNumber) &&
        Objects.equals(this.businessEmailAddress, principalsMatc.businessEmailAddress) &&
        Objects.equals(this.principalID, principalsMatc.principalID) &&
        Objects.equals(this.SSN, principalsMatc.SSN) &&
        Objects.equals(this.driverLicenseNumber, principalsMatc.driverLicenseNumber) &&
        Objects.equals(this.residentIDOrNationalID, principalsMatc.residentIDOrNationalID) &&
        Objects.equals(this.passportNumber, principalsMatc.passportNumber);
  }

  @Override
  public int hashCode() {
    return Objects.hash(name, businessPhoneNumber, businessEmailAddress, principalID, SSN, driverLicenseNumber, residentIDOrNationalID, passportNumber);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class PrincipalsMatc {\n");
    
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    businessPhoneNumber: ").append(toIndentedString(businessPhoneNumber)).append("\n");
    sb.append("    businessEmailAddress: ").append(toIndentedString(businessEmailAddress)).append("\n");
    sb.append("    principalID: ").append(toIndentedString(principalID)).append("\n");
    sb.append("    SSN: ").append(toIndentedString(SSN)).append("\n");
    sb.append("    driverLicenseNumber: ").append(toIndentedString(driverLicenseNumber)).append("\n");
    sb.append("    residentIDOrNationalID: ").append(toIndentedString(residentIDOrNationalID)).append("\n");
    sb.append("    passportNumber: ").append(toIndentedString(passportNumber)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

