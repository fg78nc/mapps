package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.Address;
import io.swagger.model.FinancialAccts;
import io.swagger.model.Principals;
import java.util.ArrayList;
import java.util.List;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * TerminatedRecord
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2020-07-02T11:43:38.078Z")

public class TerminatedRecord   {
  @JsonProperty("category")
  private String category = null;

  @JsonProperty("DBAName")
  private String dbAName = null;

  @JsonProperty("legalName")
  private String legalName = null;

  @JsonProperty("address")
  private Address address = null;

  @JsonProperty("businessPhoneNumbers")
  @Valid
  private List<String> businessPhoneNumbers = null;

  @JsonProperty("businessEmailAddress")
  private String businessEmailAddress = null;

  @JsonProperty("merchantCategoryCodes")
  @Valid
  private List<String> merchantCategoryCodes = null;

  @JsonProperty("incorportationStatus")
  private String incorportationStatus = null;

  @JsonProperty("tradeInternationally")
  private Boolean tradeInternationally = false;

  @JsonProperty("tradeOverInternet")
  private Boolean tradeOverInternet = false;

  @JsonProperty("webAddresses")
  @Valid
  private List<String> webAddresses = null;

  @JsonProperty("acquirerAssignedMerchantID")
  private String acquirerAssignedMerchantID = null;

  @JsonProperty("cardAcceptorIDs")
  @Valid
  private List<String> cardAcceptorIDs = null;

  @JsonProperty("taxID")
  private String taxID = null;

  @JsonProperty("businessRegistrationNumber")
  private String businessRegistrationNumber = null;

  @JsonProperty("paymentFacilitatorBID")
  private String paymentFacilitatorBID = null;

  @JsonProperty("paymentFacilitatorCountryOrRegion")
  private String paymentFacilitatorCountryOrRegion = null;

  @JsonProperty("financialAccts")
  private FinancialAccts financialAccts = null;

  @JsonProperty("principals")
  private Principals principals = null;

  @JsonProperty("contractStartDate")
  private String contractStartDate = null;

  @JsonProperty("contractEndDate")
  private String contractEndDate = null;

  @JsonProperty("primaryListingReason")
  private String primaryListingReason = null;

  @JsonProperty("secondaryListingReason")
  private String secondaryListingReason = null;

  public TerminatedRecord category(String category) {
    this.category = category;
    return this;
  }

  /**
   * Business Category of the Terminated Record defined as follows: 0 = Merchant 1 = Payment Facilitator 2 = Independent Sales Organization 3 = Marketplace 4 = Staged Digital Wallet Operator 5 = Sponsored Merchant
   * @return category
  **/
  @ApiModelProperty(example = "1", required = true, value = "Business Category of the Terminated Record defined as follows: 0 = Merchant 1 = Payment Facilitator 2 = Independent Sales Organization 3 = Marketplace 4 = Staged Digital Wallet Operator 5 = Sponsored Merchant")
  @NotNull

@Pattern(regexp="[0-5]") 
  public String getCategory() {
    return category;
  }

  public void setCategory(String category) {
    this.category = category;
  }

  public TerminatedRecord dbAName(String dbAName) {
    this.dbAName = dbAName;
    return this;
  }

  /**
   * The “Doing-Business-As” Name that the merchant or agent operates under.
   * @return dbAName
  **/
  @ApiModelProperty(example = "Snap Photoshop Ltd", required = true, value = "The “Doing-Business-As” Name that the merchant or agent operates under.")
  @NotNull

@Pattern(regexp="^(\\w|\\s|-|,|�|\\(|\\)|\\`|\\'|\\.|/|;|:|&|\\$|#|!|\\+|\\?|@|=|\\\\)+$") 
  public String getDbAName() {
    return dbAName;
  }

  public void setDbAName(String dbAName) {
    this.dbAName = dbAName;
  }

  public TerminatedRecord legalName(String legalName) {
    this.legalName = legalName;
    return this;
  }

  /**
   * The parent or holding company legally registered name if this name is different from the Trading Name/DBA Name. For a sole proprietor, this field shall be omitted.
   * @return legalName
  **/
  @ApiModelProperty(example = "Snap Photoshop Ltd", value = "The parent or holding company legally registered name if this name is different from the Trading Name/DBA Name. For a sole proprietor, this field shall be omitted.")

@Pattern(regexp="^(\\w|\\s|-|,|�|\\(|\\)|\\`|\\'|\\.|/|;|:|&|\\$|#|!|\\+|\\?|@|=|\\\\)+$") 
  public String getLegalName() {
    return legalName;
  }

  public void setLegalName(String legalName) {
    this.legalName = legalName;
  }

  public TerminatedRecord address(Address address) {
    this.address = address;
    return this;
  }

  /**
   * Get address
   * @return address
  **/
  @ApiModelProperty(required = true, value = "")
  @NotNull

  @Valid

  public Address getAddress() {
    return address;
  }

  public void setAddress(Address address) {
    this.address = address;
  }

  public TerminatedRecord businessPhoneNumbers(List<String> businessPhoneNumbers) {
    this.businessPhoneNumbers = businessPhoneNumbers;
    return this;
  }

  public TerminatedRecord addBusinessPhoneNumbersItem(String businessPhoneNumbersItem) {
    if (this.businessPhoneNumbers == null) {
      this.businessPhoneNumbers = new ArrayList<String>();
    }
    this.businessPhoneNumbers.add(businessPhoneNumbersItem);
    return this;
  }

  /**
   * Get businessPhoneNumbers
   * @return businessPhoneNumbers
  **/
  @ApiModelProperty(value = "")


  public List<String> getBusinessPhoneNumbers() {
    return businessPhoneNumbers;
  }

  public void setBusinessPhoneNumbers(List<String> businessPhoneNumbers) {
    this.businessPhoneNumbers = businessPhoneNumbers;
  }

  public TerminatedRecord businessEmailAddress(String businessEmailAddress) {
    this.businessEmailAddress = businessEmailAddress;
    return this;
  }

  /**
   * The primary email address registered for the merchant or agent.
   * @return businessEmailAddress
  **/
  @ApiModelProperty(example = "billsmith@snapphoto.com", value = "The primary email address registered for the merchant or agent.")

@Pattern(regexp="[A-Za-z0-9._%-]+@[A-Za-z0-9.-]+\\.[a-zA-Z]{2,4}$") 
  public String getBusinessEmailAddress() {
    return businessEmailAddress;
  }

  public void setBusinessEmailAddress(String businessEmailAddress) {
    this.businessEmailAddress = businessEmailAddress;
  }

  public TerminatedRecord merchantCategoryCodes(List<String> merchantCategoryCodes) {
    this.merchantCategoryCodes = merchantCategoryCodes;
    return this;
  }

  public TerminatedRecord addMerchantCategoryCodesItem(String merchantCategoryCodesItem) {
    if (this.merchantCategoryCodes == null) {
      this.merchantCategoryCodes = new ArrayList<String>();
    }
    this.merchantCategoryCodes.add(merchantCategoryCodesItem);
    return this;
  }

  /**
   * Get merchantCategoryCodes
   * @return merchantCategoryCodes
  **/
  @ApiModelProperty(value = "")


  public List<String> getMerchantCategoryCodes() {
    return merchantCategoryCodes;
  }

  public void setMerchantCategoryCodes(List<String> merchantCategoryCodes) {
    this.merchantCategoryCodes = merchantCategoryCodes;
  }

  public TerminatedRecord incorportationStatus(String incorportationStatus) {
    this.incorportationStatus = incorportationStatus;
    return this;
  }

  /**
   * The incorporation status registered for the merchant or agent defined as follows: 1 = Individual/Sole Proprietor 2 = Partnership 3 = Corporation 4 = Medical or Legal Corporation 5 = Association / Estate / Trust 6 = Non-Profit Organization
   * @return incorportationStatus
  **/
  @ApiModelProperty(example = "3", required = true, value = "The incorporation status registered for the merchant or agent defined as follows: 1 = Individual/Sole Proprietor 2 = Partnership 3 = Corporation 4 = Medical or Legal Corporation 5 = Association / Estate / Trust 6 = Non-Profit Organization")
  @NotNull

@Pattern(regexp="[1-6]") 
  public String getIncorportationStatus() {
    return incorportationStatus;
  }

  public void setIncorportationStatus(String incorportationStatus) {
    this.incorportationStatus = incorportationStatus;
  }

  public TerminatedRecord tradeInternationally(Boolean tradeInternationally) {
    this.tradeInternationally = tradeInternationally;
    return this;
  }

  /**
   * An indicator identifying if the merchant or agent trades more than one country.
   * @return tradeInternationally
  **/
  @ApiModelProperty(example = "true", required = true, value = "An indicator identifying if the merchant or agent trades more than one country.")
  @NotNull


  public Boolean isTradeInternationally() {
    return tradeInternationally;
  }

  public void setTradeInternationally(Boolean tradeInternationally) {
    this.tradeInternationally = tradeInternationally;
  }

  public TerminatedRecord tradeOverInternet(Boolean tradeOverInternet) {
    this.tradeOverInternet = tradeOverInternet;
    return this;
  }

  /**
   * An indicator identifying if the merchant or agent trades over the Internet.
   * @return tradeOverInternet
  **/
  @ApiModelProperty(example = "false", required = true, value = "An indicator identifying if the merchant or agent trades over the Internet.")
  @NotNull


  public Boolean isTradeOverInternet() {
    return tradeOverInternet;
  }

  public void setTradeOverInternet(Boolean tradeOverInternet) {
    this.tradeOverInternet = tradeOverInternet;
  }

  public TerminatedRecord webAddresses(List<String> webAddresses) {
    this.webAddresses = webAddresses;
    return this;
  }

  public TerminatedRecord addWebAddressesItem(String webAddressesItem) {
    if (this.webAddresses == null) {
      this.webAddresses = new ArrayList<String>();
    }
    this.webAddresses.add(webAddressesItem);
    return this;
  }

  /**
   * Get webAddresses
   * @return webAddresses
  **/
  @ApiModelProperty(value = "")


  public List<String> getWebAddresses() {
    return webAddresses;
  }

  public void setWebAddresses(List<String> webAddresses) {
    this.webAddresses = webAddresses;
  }

  public TerminatedRecord acquirerAssignedMerchantID(String acquirerAssignedMerchantID) {
    this.acquirerAssignedMerchantID = acquirerAssignedMerchantID;
    return this;
  }

  /**
   * A unique Merchant Identification Number assigned by the Acquirer.
   * @return acquirerAssignedMerchantID
  **/
  @ApiModelProperty(example = "36654773", value = "A unique Merchant Identification Number assigned by the Acquirer.")

@Pattern(regexp="^(\\w|\\s|-|,|�|\\(|\\)|\\`|\\'|\\.|/|;|:|&|\\$|#|!|\\+|\\?|@|=|\\\\)+$") 
  public String getAcquirerAssignedMerchantID() {
    return acquirerAssignedMerchantID;
  }

  public void setAcquirerAssignedMerchantID(String acquirerAssignedMerchantID) {
    this.acquirerAssignedMerchantID = acquirerAssignedMerchantID;
  }

  public TerminatedRecord cardAcceptorIDs(List<String> cardAcceptorIDs) {
    this.cardAcceptorIDs = cardAcceptorIDs;
    return this;
  }

  public TerminatedRecord addCardAcceptorIDsItem(String cardAcceptorIDsItem) {
    if (this.cardAcceptorIDs == null) {
      this.cardAcceptorIDs = new ArrayList<String>();
    }
    this.cardAcceptorIDs.add(cardAcceptorIDsItem);
    return this;
  }

  /**
   * Get cardAcceptorIDs
   * @return cardAcceptorIDs
  **/
  @ApiModelProperty(value = "")


  public List<String> getCardAcceptorIDs() {
    return cardAcceptorIDs;
  }

  public void setCardAcceptorIDs(List<String> cardAcceptorIDs) {
    this.cardAcceptorIDs = cardAcceptorIDs;
  }

  public TerminatedRecord taxID(String taxID) {
    this.taxID = taxID;
    return this;
  }

  /**
   * A Tax Identification Code registered for the merchant or agent; for example, a Value Added Tax (VAT) Number in the UK or a Federal Tax ID Number in US.
   * @return taxID
  **/
  @ApiModelProperty(example = "GB123456789", value = "A Tax Identification Code registered for the merchant or agent; for example, a Value Added Tax (VAT) Number in the UK or a Federal Tax ID Number in US.")

@Pattern(regexp="[\\p{L}\\p{Nd}\\p{Nl}\\p{Z}]*") 
  public String getTaxID() {
    return taxID;
  }

  public void setTaxID(String taxID) {
    this.taxID = taxID;
  }

  public TerminatedRecord businessRegistrationNumber(String businessRegistrationNumber) {
    this.businessRegistrationNumber = businessRegistrationNumber;
    return this;
  }

  /**
   * A Business Registration Number such as Commercial Registration, Ministry of Commerce certificate number or equivalent registration number for the merchant or agent that does not have a tax ID.
   * @return businessRegistrationNumber
  **/
  @ApiModelProperty(example = "452349600005", value = "A Business Registration Number such as Commercial Registration, Ministry of Commerce certificate number or equivalent registration number for the merchant or agent that does not have a tax ID.")

@Pattern(regexp="[\\p{L}\\p{Nd}\\p{Nl}\\p{Z}]*") 
  public String getBusinessRegistrationNumber() {
    return businessRegistrationNumber;
  }

  public void setBusinessRegistrationNumber(String businessRegistrationNumber) {
    this.businessRegistrationNumber = businessRegistrationNumber;
  }

  public TerminatedRecord paymentFacilitatorBID(String paymentFacilitatorBID) {
    this.paymentFacilitatorBID = paymentFacilitatorBID;
    return this;
  }

  /**
   * The business ID as registered with Visa to uniquely identify a payment facilitator.
   * @return paymentFacilitatorBID
  **/
  @ApiModelProperty(example = "10000108", value = "The business ID as registered with Visa to uniquely identify a payment facilitator.")

@Pattern(regexp="\\d{8}") 
  public String getPaymentFacilitatorBID() {
    return paymentFacilitatorBID;
  }

  public void setPaymentFacilitatorBID(String paymentFacilitatorBID) {
    this.paymentFacilitatorBID = paymentFacilitatorBID;
  }

  public TerminatedRecord paymentFacilitatorCountryOrRegion(String paymentFacilitatorCountryOrRegion) {
    this.paymentFacilitatorCountryOrRegion = paymentFacilitatorCountryOrRegion;
    return this;
  }

  /**
   * The country or region of the payment facilitator.
   * @return paymentFacilitatorCountryOrRegion
  **/
  @ApiModelProperty(example = "JP", value = "The country or region of the payment facilitator.")

@Pattern(regexp="([A-Z]){2}") 
  public String getPaymentFacilitatorCountryOrRegion() {
    return paymentFacilitatorCountryOrRegion;
  }

  public void setPaymentFacilitatorCountryOrRegion(String paymentFacilitatorCountryOrRegion) {
    this.paymentFacilitatorCountryOrRegion = paymentFacilitatorCountryOrRegion;
  }

  public TerminatedRecord financialAccts(FinancialAccts financialAccts) {
    this.financialAccts = financialAccts;
    return this;
  }

  /**
   * Get financialAccts
   * @return financialAccts
  **/
  @ApiModelProperty(value = "")

  @Valid

  public FinancialAccts getFinancialAccts() {
    return financialAccts;
  }

  public void setFinancialAccts(FinancialAccts financialAccts) {
    this.financialAccts = financialAccts;
  }

  public TerminatedRecord principals(Principals principals) {
    this.principals = principals;
    return this;
  }

  /**
   * Get principals
   * @return principals
  **/
  @ApiModelProperty(value = "")

  @Valid

  public Principals getPrincipals() {
    return principals;
  }

  public void setPrincipals(Principals principals) {
    this.principals = principals;
  }

  public TerminatedRecord contractStartDate(String contractStartDate) {
    this.contractStartDate = contractStartDate;
    return this;
  }

  /**
   * The date on which the merchant's or agent's contract agreement was granted.
   * @return contractStartDate
  **/
  @ApiModelProperty(example = "2019-11-01", required = true, value = "The date on which the merchant's or agent's contract agreement was granted.")
  @NotNull

@Pattern(regexp="\\d{4}\\-(0[1-9]|1[012])\\-(0[1-9]|[12][0-9]|3[01])$") 
  public String getContractStartDate() {
    return contractStartDate;
  }

  public void setContractStartDate(String contractStartDate) {
    this.contractStartDate = contractStartDate;
  }

  public TerminatedRecord contractEndDate(String contractEndDate) {
    this.contractEndDate = contractEndDate;
    return this;
  }

  /**
   * The date on which the merchant's or agent's contract agreement was terminated.
   * @return contractEndDate
  **/
  @ApiModelProperty(example = "2019-11-14", required = true, value = "The date on which the merchant's or agent's contract agreement was terminated.")
  @NotNull

@Pattern(regexp="\\d{4}\\-(0[1-9]|1[012])\\-(0[1-9]|[12][0-9]|3[01])$") 
  public String getContractEndDate() {
    return contractEndDate;
  }

  public void setContractEndDate(String contractEndDate) {
    this.contractEndDate = contractEndDate;
  }

  public TerminatedRecord primaryListingReason(String primaryListingReason) {
    this.primaryListingReason = primaryListingReason;
    return this;
  }

  /**
   * The primary reason for the termination of the merchant's or agent's contract.
   * @return primaryListingReason
  **/
  @ApiModelProperty(example = "01", required = true, value = "The primary reason for the termination of the merchant's or agent's contract.")
  @NotNull

@Pattern(regexp="[0-9][0-9]") 
  public String getPrimaryListingReason() {
    return primaryListingReason;
  }

  public void setPrimaryListingReason(String primaryListingReason) {
    this.primaryListingReason = primaryListingReason;
  }

  public TerminatedRecord secondaryListingReason(String secondaryListingReason) {
    this.secondaryListingReason = secondaryListingReason;
    return this;
  }

  /**
   * The secondary reason for the termination of the merchant's or agent's contract.
   * @return secondaryListingReason
  **/
  @ApiModelProperty(example = "08", value = "The secondary reason for the termination of the merchant's or agent's contract.")

@Pattern(regexp="[0-9][0-9]") 
  public String getSecondaryListingReason() {
    return secondaryListingReason;
  }

  public void setSecondaryListingReason(String secondaryListingReason) {
    this.secondaryListingReason = secondaryListingReason;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    TerminatedRecord terminatedRecord = (TerminatedRecord) o;
    return Objects.equals(this.category, terminatedRecord.category) &&
        Objects.equals(this.dbAName, terminatedRecord.dbAName) &&
        Objects.equals(this.legalName, terminatedRecord.legalName) &&
        Objects.equals(this.address, terminatedRecord.address) &&
        Objects.equals(this.businessPhoneNumbers, terminatedRecord.businessPhoneNumbers) &&
        Objects.equals(this.businessEmailAddress, terminatedRecord.businessEmailAddress) &&
        Objects.equals(this.merchantCategoryCodes, terminatedRecord.merchantCategoryCodes) &&
        Objects.equals(this.incorportationStatus, terminatedRecord.incorportationStatus) &&
        Objects.equals(this.tradeInternationally, terminatedRecord.tradeInternationally) &&
        Objects.equals(this.tradeOverInternet, terminatedRecord.tradeOverInternet) &&
        Objects.equals(this.webAddresses, terminatedRecord.webAddresses) &&
        Objects.equals(this.acquirerAssignedMerchantID, terminatedRecord.acquirerAssignedMerchantID) &&
        Objects.equals(this.cardAcceptorIDs, terminatedRecord.cardAcceptorIDs) &&
        Objects.equals(this.taxID, terminatedRecord.taxID) &&
        Objects.equals(this.businessRegistrationNumber, terminatedRecord.businessRegistrationNumber) &&
        Objects.equals(this.paymentFacilitatorBID, terminatedRecord.paymentFacilitatorBID) &&
        Objects.equals(this.paymentFacilitatorCountryOrRegion, terminatedRecord.paymentFacilitatorCountryOrRegion) &&
        Objects.equals(this.financialAccts, terminatedRecord.financialAccts) &&
        Objects.equals(this.principals, terminatedRecord.principals) &&
        Objects.equals(this.contractStartDate, terminatedRecord.contractStartDate) &&
        Objects.equals(this.contractEndDate, terminatedRecord.contractEndDate) &&
        Objects.equals(this.primaryListingReason, terminatedRecord.primaryListingReason) &&
        Objects.equals(this.secondaryListingReason, terminatedRecord.secondaryListingReason);
  }

  @Override
  public int hashCode() {
    return Objects.hash(category, dbAName, legalName, address, businessPhoneNumbers, businessEmailAddress, merchantCategoryCodes, incorportationStatus, tradeInternationally, tradeOverInternet, webAddresses, acquirerAssignedMerchantID, cardAcceptorIDs, taxID, businessRegistrationNumber, paymentFacilitatorBID, paymentFacilitatorCountryOrRegion, financialAccts, principals, contractStartDate, contractEndDate, primaryListingReason, secondaryListingReason);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class TerminatedRecord {\n");
    
    sb.append("    category: ").append(toIndentedString(category)).append("\n");
    sb.append("    dbAName: ").append(toIndentedString(dbAName)).append("\n");
    sb.append("    legalName: ").append(toIndentedString(legalName)).append("\n");
    sb.append("    address: ").append(toIndentedString(address)).append("\n");
    sb.append("    businessPhoneNumbers: ").append(toIndentedString(businessPhoneNumbers)).append("\n");
    sb.append("    businessEmailAddress: ").append(toIndentedString(businessEmailAddress)).append("\n");
    sb.append("    merchantCategoryCodes: ").append(toIndentedString(merchantCategoryCodes)).append("\n");
    sb.append("    incorportationStatus: ").append(toIndentedString(incorportationStatus)).append("\n");
    sb.append("    tradeInternationally: ").append(toIndentedString(tradeInternationally)).append("\n");
    sb.append("    tradeOverInternet: ").append(toIndentedString(tradeOverInternet)).append("\n");
    sb.append("    webAddresses: ").append(toIndentedString(webAddresses)).append("\n");
    sb.append("    acquirerAssignedMerchantID: ").append(toIndentedString(acquirerAssignedMerchantID)).append("\n");
    sb.append("    cardAcceptorIDs: ").append(toIndentedString(cardAcceptorIDs)).append("\n");
    sb.append("    taxID: ").append(toIndentedString(taxID)).append("\n");
    sb.append("    businessRegistrationNumber: ").append(toIndentedString(businessRegistrationNumber)).append("\n");
    sb.append("    paymentFacilitatorBID: ").append(toIndentedString(paymentFacilitatorBID)).append("\n");
    sb.append("    paymentFacilitatorCountryOrRegion: ").append(toIndentedString(paymentFacilitatorCountryOrRegion)).append("\n");
    sb.append("    financialAccts: ").append(toIndentedString(financialAccts)).append("\n");
    sb.append("    principals: ").append(toIndentedString(principals)).append("\n");
    sb.append("    contractStartDate: ").append(toIndentedString(contractStartDate)).append("\n");
    sb.append("    contractEndDate: ").append(toIndentedString(contractEndDate)).append("\n");
    sb.append("    primaryListingReason: ").append(toIndentedString(primaryListingReason)).append("\n");
    sb.append("    secondaryListingReason: ").append(toIndentedString(secondaryListingReason)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

